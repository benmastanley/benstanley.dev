Client Executable (location.exe) file path:
Networking UI\locationUI\locationUI\bin\debug\location.exe

Client Visual Studio solution file path:
Networking UI\locationUI\locationUI.sln


Server Executable (locationserver.exe) file path:
Networking UI\locationserverUI\locationserverUI\bin\debug\locationserver.exe

Server Visual Studio solution file path:
Networking UI\locationServerUI\locationServerUI.sln


NOTE:
	- Could only change the client/server executable name, and not 
	  the path name/solution name (from locationUI to location, 
	  and locationserverUI to locationserver).
	- The server UI logging feature seems to work better when 
	  launched from visual studio as opposed to from cmd.