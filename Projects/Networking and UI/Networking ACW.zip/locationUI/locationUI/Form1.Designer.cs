﻿namespace locationUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hostnameLabel = new System.Windows.Forms.Label();
            this.portLabel = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.locationLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.h1button = new System.Windows.Forms.RadioButton();
            this.h0button = new System.Windows.Forms.RadioButton();
            this.h9button = new System.Windows.Forms.RadioButton();
            this.whoisButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.lookupButton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.userTextBox = new System.Windows.Forms.TextBox();
            this.locationTextBox = new System.Windows.Forms.TextBox();
            this.hostnameTextBox = new System.Windows.Forms.TextBox();
            this.portTextBox = new System.Windows.Forms.TextBox();
            this.timeoutTextBox = new System.Windows.Forms.TextBox();
            this.clientInteractionsListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.enableDebugging = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // hostnameLabel
            // 
            this.hostnameLabel.AutoSize = true;
            this.hostnameLabel.Location = new System.Drawing.Point(272, 34);
            this.hostnameLabel.Name = "hostnameLabel";
            this.hostnameLabel.Size = new System.Drawing.Size(58, 13);
            this.hostnameLabel.TabIndex = 0;
            this.hostnameLabel.Text = "Hostname:";
            // 
            // portLabel
            // 
            this.portLabel.AutoSize = true;
            this.portLabel.Location = new System.Drawing.Point(301, 71);
            this.portLabel.Name = "portLabel";
            this.portLabel.Size = new System.Drawing.Size(29, 13);
            this.portLabel.TabIndex = 1;
            this.portLabel.Text = "Port:";
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.Location = new System.Drawing.Point(42, 34);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(32, 13);
            this.userLabel.TabIndex = 2;
            this.userLabel.Text = "User:";
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(27, 79);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(47, 13);
            this.locationLabel.TabIndex = 3;
            this.locationLabel.Text = "location:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.h1button);
            this.groupBox1.Controls.Add(this.h0button);
            this.groupBox1.Controls.Add(this.h9button);
            this.groupBox1.Controls.Add(this.whoisButton);
            this.groupBox1.Location = new System.Drawing.Point(28, 164);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(430, 82);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Protocol:";
            // 
            // h1button
            // 
            this.h1button.AutoSize = true;
            this.h1button.Location = new System.Drawing.Point(320, 33);
            this.h1button.Name = "h1button";
            this.h1button.Size = new System.Drawing.Size(74, 17);
            this.h1button.TabIndex = 8;
            this.h1button.TabStop = true;
            this.h1button.Text = "HTTP/1.1";
            this.h1button.UseVisualStyleBackColor = true;
            // 
            // h0button
            // 
            this.h0button.AutoSize = true;
            this.h0button.Location = new System.Drawing.Point(211, 33);
            this.h0button.Name = "h0button";
            this.h0button.Size = new System.Drawing.Size(74, 17);
            this.h0button.TabIndex = 7;
            this.h0button.TabStop = true;
            this.h0button.Text = "HTTP/1.0";
            this.h0button.UseVisualStyleBackColor = true;
            // 
            // h9button
            // 
            this.h9button.AutoSize = true;
            this.h9button.Location = new System.Drawing.Point(102, 33);
            this.h9button.Name = "h9button";
            this.h9button.Size = new System.Drawing.Size(74, 17);
            this.h9button.TabIndex = 6;
            this.h9button.TabStop = true;
            this.h9button.Text = "HTTP/0.9";
            this.h9button.UseVisualStyleBackColor = true;
            // 
            // whoisButton
            // 
            this.whoisButton.AutoSize = true;
            this.whoisButton.Location = new System.Drawing.Point(18, 33);
            this.whoisButton.Name = "whoisButton";
            this.whoisButton.Size = new System.Drawing.Size(55, 17);
            this.whoisButton.TabIndex = 5;
            this.whoisButton.TabStop = true;
            this.whoisButton.Text = "Whois";
            this.whoisButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(260, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Timeout (ms):";
            // 
            // lookupButton
            // 
            this.lookupButton.Location = new System.Drawing.Point(28, 109);
            this.lookupButton.Name = "lookupButton";
            this.lookupButton.Size = new System.Drawing.Size(93, 40);
            this.lookupButton.TabIndex = 6;
            this.lookupButton.Text = "LOOKUP";
            this.lookupButton.UseVisualStyleBackColor = true;
            this.lookupButton.Click += new System.EventHandler(this.lookupButton_Click);
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(127, 109);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(93, 40);
            this.updateButton.TabIndex = 7;
            this.updateButton.Text = "UPDATE";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // userTextBox
            // 
            this.userTextBox.Location = new System.Drawing.Point(80, 31);
            this.userTextBox.Name = "userTextBox";
            this.userTextBox.Size = new System.Drawing.Size(100, 20);
            this.userTextBox.TabIndex = 8;
            // 
            // locationTextBox
            // 
            this.locationTextBox.Location = new System.Drawing.Point(80, 76);
            this.locationTextBox.Name = "locationTextBox";
            this.locationTextBox.Size = new System.Drawing.Size(100, 20);
            this.locationTextBox.TabIndex = 9;
            // 
            // hostnameTextBox
            // 
            this.hostnameTextBox.Location = new System.Drawing.Point(336, 31);
            this.hostnameTextBox.Name = "hostnameTextBox";
            this.hostnameTextBox.Size = new System.Drawing.Size(122, 20);
            this.hostnameTextBox.TabIndex = 10;
            this.hostnameTextBox.Text = "whois.net.dcs.hull.ac.uk";
            // 
            // portTextBox
            // 
            this.portTextBox.Location = new System.Drawing.Point(336, 68);
            this.portTextBox.Name = "portTextBox";
            this.portTextBox.Size = new System.Drawing.Size(43, 20);
            this.portTextBox.TabIndex = 11;
            this.portTextBox.Text = "43";
            // 
            // timeoutTextBox
            // 
            this.timeoutTextBox.Location = new System.Drawing.Point(336, 105);
            this.timeoutTextBox.Name = "timeoutTextBox";
            this.timeoutTextBox.Size = new System.Drawing.Size(43, 20);
            this.timeoutTextBox.TabIndex = 12;
            this.timeoutTextBox.Text = "1000";
            // 
            // clientInteractionsListBox
            // 
            this.clientInteractionsListBox.FormattingEnabled = true;
            this.clientInteractionsListBox.Location = new System.Drawing.Point(27, 264);
            this.clientInteractionsListBox.Name = "clientInteractionsListBox";
            this.clientInteractionsListBox.Size = new System.Drawing.Size(430, 121);
            this.clientInteractionsListBox.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 249);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Client Log";
            // 
            // enableDebugging
            // 
            this.enableDebugging.AutoSize = true;
            this.enableDebugging.Location = new System.Drawing.Point(304, 136);
            this.enableDebugging.Name = "enableDebugging";
            this.enableDebugging.Size = new System.Drawing.Size(114, 17);
            this.enableDebugging.TabIndex = 14;
            this.enableDebugging.Text = "Enable Debugging";
            this.enableDebugging.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(483, 406);
            this.Controls.Add(this.enableDebugging);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.clientInteractionsListBox);
            this.Controls.Add(this.timeoutTextBox);
            this.Controls.Add(this.portTextBox);
            this.Controls.Add(this.hostnameTextBox);
            this.Controls.Add(this.locationTextBox);
            this.Controls.Add(this.userTextBox);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.lookupButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.locationLabel);
            this.Controls.Add(this.userLabel);
            this.Controls.Add(this.portLabel);
            this.Controls.Add(this.hostnameLabel);
            this.Name = "Form1";
            this.Text = "Client";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label hostnameLabel;
        private System.Windows.Forms.Label portLabel;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton h1button;
        private System.Windows.Forms.RadioButton h0button;
        private System.Windows.Forms.RadioButton h9button;
        private System.Windows.Forms.RadioButton whoisButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button lookupButton;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.TextBox userTextBox;
        private System.Windows.Forms.TextBox locationTextBox;
        private System.Windows.Forms.TextBox hostnameTextBox;
        private System.Windows.Forms.TextBox portTextBox;
        private System.Windows.Forms.TextBox timeoutTextBox;
        private System.Windows.Forms.ListBox clientInteractionsListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox enableDebugging;
    }
}

