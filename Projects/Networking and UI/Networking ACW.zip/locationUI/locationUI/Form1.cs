﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.IO;
using System.Diagnostics;

namespace locationUI
{
    public partial class Form1 : Form
    {
        string error = "";
        string user = null;
        string location = null;
        string protocol = "whois";
        string hostname = null;
        int port = 43;
        int timeout = 1000;
        List<string> clientInteractions = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }
        private void lookupButton_Click(object sender, EventArgs e)
        {
            if (enableDebugging.Checked)
            {
                Debugger.Launch();
            }
            error = "";
            valuesGiven();
            getProtocol();
            if (error != "")
            {
                MessageBox.Show("In order to perform the lookup:\r\n\r\n" + error);
            }
            else            // PERFORM LOOKUP------------------------------------------------------------
            {
                try
                {
                    user = userTextBox.Text;
                    location = locationTextBox.Text;
                    hostname = hostnameTextBox.Text;
                    string temp = null;
                    List<string> serverResponse = new List<string>();
                    MessageBox.Show($"User: {user}\r\n\r\nProtocol: {protocol}\r\n" +
                        $"Hostname: {hostname}\r\n" +
                        $"Port: {port}\r\nTimeout: {timeout}");

                    TcpClient client = new TcpClient();
                    client.Connect(hostname, port);
                    StreamWriter sw = new StreamWriter(client.GetStream());
                    StreamReader sr = new StreamReader(client.GetStream());
                    if (timeout != 0)
                    {
                        client.SendTimeout = timeout;
                        client.ReceiveTimeout = timeout;
                    }

                    if (!client.Connected)
                    {
                        Console.WriteLine("Unable to connect to server");
                    }
                    switch (protocol)
                    {
                        case "whois":
                            try
                            {
                                sw.Write(user + "\r\n");
                                sw.Flush();
                                string response = "";
                                response = sr.ReadToEnd().ToString();
                                if (response == "ERROR: no entries found\r\n")
                                {
                                    MessageBox.Show(response);
                                }
                                else
                                {
                                    MessageBox.Show($"{user} is {response}");
                                    clientInteractions.Add($"{user} is {response}");
                                    RefreshListBox();
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Unable to handle request -- whois protocol lookup");
                            }
                            break;

                        case "h9":
                            try
                            {
                                sw.Write($"GET /{user}\r\n");
                                sw.Flush();
                                temp = sr.ReadToEnd().ToString();
                                int locInd = temp.IndexOf("\r\n\r\n");
                                if(temp.Contains("404 Not Found"))
                                {
                                    MessageBox.Show("ERROR: no entries found\r\n");
                                }
                                else
                                {
                                    temp = temp.Substring(locInd + 4);
                                    MessageBox.Show($"{user} is {temp}");
                                    clientInteractions.Add($"{user} is {temp}");
                                    RefreshListBox();
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Unable to handle request -- HTTP 0.9 protocol lookup");
                            }
                            break;

                        case "h0":
                            try
                            {
                                sw.Write($"GET /?{user} HTTP/1.0\r\n\r\n");
                                sw.Flush();
                                temp = sr.ReadToEnd();
                                int locInd = temp.IndexOf("\r\n\r\n");
                                if(temp.Contains("404 Not Found"))
                                {
                                    MessageBox.Show("ERROR: no entries found\r\n");
                                }
                                else
                                {
                                    temp = temp.Substring(locInd + 4);
                                    MessageBox.Show($"{user} is {temp}");
                                    clientInteractions.Add($"{user} is {temp}");
                                    RefreshListBox();
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Unable to handle request -- HTTP 1.0 protocol lookup");
                            }
                            break;

                        case "h1":
                            try
                            {
                                sw.Write("GET /?name=" + user + " HTTP/1.1\r\nHost: " + hostname + "\r\n\r\n");
                                sw.Flush();

                                if (port == 80)
                                {
                                    while (sr.Peek() >= 0)
                                    {
                                        temp = sr.ReadLine().ToString();
                                        serverResponse.Add(temp);
                                    }
                                    temp = "";
                                    int linebreak = serverResponse.IndexOf("");
                                    for (int i = linebreak + 1; i < serverResponse.Count; i++)
                                    {
                                        temp += serverResponse[i];
                                        temp += "\r\n";
                                    }
                                    MessageBox.Show($"{user} is {temp}");
                                    clientInteractions.Add($"{user} is {temp}");
                                    RefreshListBox();
                                }
                                else
                                {
                                    temp = sr.ReadToEnd().ToString();
                                    int locInd = temp.IndexOf("\r\n\r\n");
                                    if (temp.Contains("404 Not Found"))
                                    {
                                        MessageBox.Show("ERROR: no entries found\r\n");
                                    }
                                    else
                                    {
                                        temp = temp.Substring(locInd + 4);
                                        MessageBox.Show($"{user} is {temp}");
                                        clientInteractions.Add($"{user} is {temp}");
                                        RefreshListBox();
                                    }
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Unable to handle request -- HTTP 1.1 protocol lookup");
                            }
                            break;
                    }
                }
                catch
                {
                    MessageBox.Show("Unable to handle lookup request");
                }
            }
        }
        private void updateButton_Click(object sender, EventArgs e)
        {
            if (enableDebugging.Checked)
            {
                Debugger.Launch();
            }
            error = "";
            valuesGiven();
            getProtocol();
            if ((locationTextBox.Text == "") || (locationTextBox.Text == null))
            {
                error += "Location text box cannot be empty!\r\n";
            }
            if (error != "")
            {
                MessageBox.Show("In order to perform the update:\r\n\r\n" + error);
            }
            else            // PERFORM UPDATE------------------------------------------------------------
            {
                user = userTextBox.Text;
                location = locationTextBox.Text;
                hostname = hostnameTextBox.Text;
                string temp = null;
                List<string> serverResponse = new List<string>();
                MessageBox.Show($"User: {user}\r\nLocation: {location}\r\n\r\nProtocol: {protocol}\r\n" +
                    $"Hostname: {hostname}\r\n" +
                    $"Port: {port}\r\nTimeout: {timeout}");

                TcpClient client = new TcpClient();
                client.Connect(hostname, port);
                StreamWriter sw = new StreamWriter(client.GetStream());
                StreamReader sr = new StreamReader(client.GetStream());
                if (timeout != 0)
                {
                    client.SendTimeout = timeout;
                    client.ReceiveTimeout = timeout;
                }
                if (!client.Connected)
                {
                    Console.WriteLine("Unable to connect to server");
                }
                switch (protocol)
                {
                    case "whois":
                        try
                        {
                            sw.Write($"{user} {location}\r\n");
                            sw.Flush();
                            temp = sr.ReadToEnd().ToString();
                            if (temp == "OK\r\n")
                            {
                                MessageBox.Show($"{user} location changed to be {location}");
                                clientInteractions.Add($"{user} location changed to be {location}");
                                RefreshListBox();
                            }
                            else
                            {
                                MessageBox.Show($"~NOT~ {user} location changed to be {location}\r\n");
                                clientInteractions.Add($"~NOT~ {user} location changed to be {location}\r\n");
                                RefreshListBox();
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Unable to handle request -- whois protocol update");
                        }
                        break;

                    case "h9":
                        try
                        {
                            sw.Write($"PUT /{user}\r\n\r\n{location}\r\n");
                            sw.Flush();
                            MessageBox.Show($"{user} location changed to be {location}");
                            clientInteractions.Add($"{user} location changed to be {location}");
                            RefreshListBox();
                        }
                        catch
                        {
                            MessageBox.Show("Unable to handle request -- HTTP 0.9 protocol update");
                        }
                        break;

                    case "h0":
                        try
                        {
                            char[] lng = location.ToCharArray();
                            sw.Write($"POST /{user} HTTP/1.0\r\nContent-Length: {lng.Length}\r\n\r\n{location}");
                            sw.Flush();
                            MessageBox.Show($"{user} location changed to be {location}");
                            clientInteractions.Add($"{user} location changed to be {location}");
                            RefreshListBox();
                        }
                        catch
                        {
                            MessageBox.Show("Unable to handle request -- HTTP 1.0 protocol update");
                        }
                        break;

                    case "h1":
                        try
                        {
                            string test = $"name={user}&location={location}";
                            char[] lng2 = test.ToCharArray();
                            sw.Write($"POST / HTTP/1.1\r\nHost: {hostname}\r\nContent-Length: {lng2.Length}\r\n\r\nname={user}&location={location}");
                            sw.Flush();
                            MessageBox.Show($"{user} location changed to be {location}");
                            clientInteractions.Add($"{user} location changed to be {location}");
                            RefreshListBox();
                        }
                        catch
                        {
                            MessageBox.Show("Unable to handle request -- HTTP 1.1 protocol update");
                        }
                        break;
                }
            }
        }
        private void getProtocol()
        {
            if(whoisButton.Checked)
            {
                protocol = "whois";
            }
            else if(h9button.Checked)
            {
                protocol = "h9";
            }
            else if(h0button.Checked)
            {
                protocol = "h0";
            }
            else if(h1button.Checked)
            {
                protocol = "h1";
            }
        }
        public void valuesGiven()
        {
            if ((hostnameTextBox.Text == "") || (hostnameTextBox.Text == null))
            {
                error += "Hostname text box cannot be empty!\r\n";
            }
            if ((portTextBox.Text == "") || (portTextBox.Text == null))
            {
                error += "Port text box cannot be empty!\r\n";
            }
            try
            {
                port = int.Parse(portTextBox.Text);
            }
            catch
            {
                error += "Port must be an interger i.e. 43\r\n";
            }
            try
            {
                if(timeoutTextBox.Text != null)
                {
                    timeout = int.Parse(timeoutTextBox.Text);
                }
                if(timeoutTextBox.Text == null)
                {
                    timeout = 0;
                }
            }
            catch
            {
                error += "Timeout(ms) must be an interger i.e. 1000ms = 1 second, " +
                    "or set to zero / leave empty for no timeout implementation\r\n";
            }
        }
        public void RefreshListBox()
        {
            clientInteractionsListBox.Items.Clear();
            for (int i = 0; i < clientInteractions.Count; i++)
            {
                clientInteractionsListBox.Items.Add(clientInteractions[i]);
            }
            clientInteractionsListBox.Update();
        }
    }
}