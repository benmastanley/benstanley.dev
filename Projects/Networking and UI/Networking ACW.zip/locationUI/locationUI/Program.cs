﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;

namespace locationUI
{
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            string mode = "Console";
            if (args.Length == 0)
            {
                mode = "GUI";
            }
            if (mode == "GUI")
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());
            }
            else
            {
                List<string> myList = new List<string>();
                string error = "";
                string hostname = "whois.net.dcs.hull.ac.uk";
                int port = 43;
                bool h = false;
                bool p = false;
                string protocol = "Whois";
                int timeout = 1000;
                string[] Input = null;

                if (args.Length == 0)
                {
                    error += "No arguments provided\r\n";
                }

                foreach (string s in args)
                {
                    myList.Add(s);
                }

                for (int i = 0; i < args.Length; i++)
                {
                    if ((args[i] == "-h") && (h == false))
                    {
                        myList.Remove("-h");
                        try
                        {
                            hostname = args[i + 1];
                            myList.Remove(hostname);
                        }
                        catch
                        {
                            Console.WriteLine("Error attempting to assign hostname");
                        }
                        h = true;
                        continue;
                    }
                    if ((args[i] == "-p") && (p == false))
                    {
                        myList.Remove("-p");
                        try
                        {
                            myList.Remove((args[i + 1]));
                            port = int.Parse(args[i + 1]);
                        }
                        catch
                        {
                            port = 43;
                            Console.WriteLine("Unable to use this port - default port 43 being used");
                        }
                        p = true;
                        continue;
                    }
                    if (args[i] == "-t")
                    {
                        myList.Remove("-t");
                        try
                        {
                            myList.Remove((args[i + 1]));
                            timeout = int.Parse(args[i + 1]);
                        }
                        catch
                        {
                            Console.WriteLine("Unable to set timeout - default 1000ms being used");
                            timeout = 1000;
                        }
                    }
                    if (args[i] == "-d")
                    {
                        myList.Remove("-d");
                        Debugger.Launch();
                    }
                }

                for (int x = 0; x < myList.Count; x++)
                {
                    if (myList[x] == "-h0")
                    {
                        protocol = "1.0";
                        myList.Remove("-h0");
                        break;
                    }
                    if (myList[x] == "-h1")
                    {
                        protocol = "1.1";
                        myList.Remove("-h1");
                        break;
                    }
                    if (myList[x] == "-h9")
                    {
                        protocol = "0.9";
                        myList.Remove("-h9");
                        break;
                    }
                }

                if (myList.Count == 0)
                {
                    error += "No user provided\r\n";
                }
                if (myList.Count > 2)
                {
                    for (int i = 2; i < myList.Count; i++)
                    {
                        myList[1] += " ";
                        myList[1] += myList[i];
                    }
                    myList[1].TrimEnd(' ');
                }

                if (myList.Count == 1)
                {
                    Input = new string[1];
                }
                if (myList.Count >= 2)
                {
                    Input = new string[2];
                }
                if (myList.Count != 0)
                {
                    for (int i = 0; i < Input.Length; i++)
                    {
                        Input[i] = myList[i];
                    }
                }

                try
                {
                    string noArgTest = args[0];
                    TcpClient client = new TcpClient();
                    client.Connect(hostname, port);
                    StreamWriter sw = new StreamWriter(client.GetStream());
                    StreamReader sr = new StreamReader(client.GetStream());
                    if (timeout != 0)
                    {
                        client.SendTimeout = timeout;
                        client.ReceiveTimeout = timeout;
                    }

                    string temp = null;
                    List<string> serverResponse = new List<string>();

                    if (!client.Connected)
                    {
                        Console.WriteLine("Unable to connect to server");
                    }
                    switch (protocol)
                    {
                        case "0.9":    //HTTP 0.9 STYLE REQUESTS
                            if (Input.Length == 1) //HTTP 0.9 LOOKUP
                            {
                                try
                                {
                                    sw.Write($"GET /{Input[0]}\r\n");
                                    sw.Flush();
                                    temp = sr.ReadToEnd().ToString();
                                    int locInd = temp.IndexOf("\r\n\r\n");
                                    if (temp.Contains("404 Not Found"))
                                    {
                                        Console.WriteLine("ERROR: no entries found\r\n");
                                    }
                                    else
                                    {
                                        temp = temp.Substring(locInd + 4);
                                        Console.WriteLine($"{Input[0]} is {temp}");
                                    }
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- HTTP 0.9 protocol lookup");
                                }
                            }
                            if (Input.Length == 2) //HTTP 0.9 UPDATE
                            {
                                try
                                {
                                    sw.Write($"PUT /{Input[0]}\r\n\r\n{Input[1]}\r\n");
                                    sw.Flush();
                                    temp = sr.ReadToEnd();
                                    Console.WriteLine($"{Input[0]} location changed to be {Input[1]}");
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- HTTP 0.9 protocol update");
                                }
                            }
                            break;

                        case "1.0":     //HTTP 1.0 STYLE REQUESTS
                            if (Input.Length == 1) //HTTP 1.0 LOOKUP
                            {
                                try
                                {
                                    sw.Write($"GET /?{Input[0]} HTTP/1.0\r\n\r\n");
                                    sw.Flush();
                                    temp = sr.ReadToEnd().ToString();
                                    int locInd = temp.IndexOf("\r\n\r\n");
                                    if (temp.Contains("404 Not Found"))
                                    {
                                        Console.WriteLine("ERROR: no entries found\r\n");
                                    }
                                    else
                                    {
                                        temp = temp.Substring(locInd + 4);
                                        Console.WriteLine($"{Input[0]} is {temp}");
                                    }
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- HTTP 1.0 protocol lookup");
                                }
                            }
                            if (Input.Length == 2) //HTTP 1.0 UPDATE
                            {
                                try
                                {
                                    char[] lng = Input[1].ToCharArray();
                                    sw.Write($"POST /{Input[0]} HTTP/1.0\r\nContent-Length: {lng.Length}\r\n\r\n{Input[1]}");
                                    sw.Flush();
                                    temp = sr.ReadToEnd().ToString();
                                    Console.WriteLine($"{Input[0]} location changed to be {Input[1]}");
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- HTTP 1.0 protocol update");
                                }
                            }
                            break;

                        case "1.1":    //HTTP 1.1 STYLE REQUESTS
                            if (Input.Length == 1) //HTTP 1.1 LOOKUP
                            {
                                try
                                {
                                    sw.Write("GET /?name=" + Input[0] + " HTTP/1.1\r\nHost: " + hostname + "\r\n\r\n");
                                    sw.Flush();

                                    if (port == 80) // IF PORT 80, OUTPUT IS DIFFERENT
                                    {
                                        while (sr.Peek() >= 0)
                                        {
                                            temp = sr.ReadLine().ToString();
                                            serverResponse.Add(temp);
                                        }
                                        temp = "";
                                        int linebreak = serverResponse.IndexOf("");
                                        for (int i = linebreak + 1; i < serverResponse.Count; i++)
                                        {
                                            temp += serverResponse[i];
                                            temp += "\r\n";
                                        }
                                        Console.WriteLine($"{Input[0]} is {temp}");
                                    }
                                    else
                                    {
                                        temp = sr.ReadToEnd().ToString();
                                        int locInd = temp.IndexOf("\r\n\r\n");
                                        if (temp.Contains("404 Not Found"))
                                        {
                                            Console.WriteLine("ERROR: no entries found\r\n");
                                        }
                                        else
                                        {
                                            temp = temp.Substring(locInd + 4);
                                            Console.WriteLine($"{Input[0]} is {temp}");
                                        }
                                    }
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- HTTP 1.1 protocol lookup");
                                }
                            }
                            if (Input.Length == 2) //HTTP 1.1 UPDATE
                            {
                                try
                                {
                                    string test = $"name={Input[0]}&location={Input[1]}";
                                    char[] lng2 = test.ToCharArray();
                                    sw.Write($"POST / HTTP/1.1\r\nHost: {hostname}\r\nContent-Length: {lng2.Length}\r\n\r\nname={Input[0]}&location={Input[1]}");
                                    sw.Flush();
                                    temp = sr.ReadToEnd().ToString();
                                    Console.WriteLine($"{Input[0]} location changed to be {Input[1]}");
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- HTTP 1.1 protocol update");
                                }
                            }
                            break;

                        case "Whois":
                        default:    // WHOIS STYLE REQUESTS
                            if (Input.Length == 1) // WHOIS LOOKUP
                            {
                                try
                                {
                                    sw.Write(Input[0] + "\r\n");
                                    sw.Flush();
                                    string response = "";
                                    response = sr.ReadToEnd().ToString();

                                    if (response == "ERROR: no entries found\r\n")
                                    {
                                        Console.WriteLine(response);
                                    }
                                    else
                                    {
                                        Console.WriteLine($"{Input[0]} is {response}");
                                    }
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- whois protocol lookup");
                                }

                            }
                            if (Input.Length == 2) // WHOIS UPDATE
                            {
                                try
                                {
                                    sw.Write($"{Input[0]} {Input[1]}\r\n");
                                    sw.Flush();
                                    temp = sr.ReadToEnd().ToString();
                                    if (temp == "OK\r\n")
                                    {
                                        Console.WriteLine($"{Input[0]} location changed to be {Input[1]}\r\n");
                                    }
                                    else
                                    {
                                        Console.WriteLine($"~NOT~ {Input[0]} location changed to be {Input[1]}\r\n");
                                    }
                                }
                                catch
                                {
                                    Console.WriteLine("Unable to handle request -- whois protocol update");
                                }
                            }
                            break;
                    }
                }
                catch (Exception e)
                {
                    if (error == "")
                    {
                        error += "Client unable to handle request.\r\n";
                    }
                    Console.WriteLine(error + e);
                }
            }
        }
    }
}