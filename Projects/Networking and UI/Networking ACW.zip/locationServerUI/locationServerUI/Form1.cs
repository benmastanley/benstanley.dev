﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Diagnostics;

namespace locationServerUI
{
    public partial class Form1 : Form
    {
        public static Dictionary<string, string> userLocations = new Dictionary<string, string>();
        public static Logging Log;
        public static string DatabaseLocation = null;
        public static int serverTimeout = 1000;
        string userAndLocation;
        string addUser;
        string addLocation;
        string filename = null;
        string error = "";
        public static bool serverRunning = false;
        public Form1(string[] args)
        {
            InitializeComponent();
            
            for (int i = 0; i < args.Length; i++)
            {
                switch (args[i])
                {
                    case "-l":
                        try
                        {
                            filename = args[i + 1];
                            LogSaveTextBox.Text = filename;
                        }
                        catch
                        {
                            error += "Unable to set log save location\r\n";
                        }
                        break;
                    case "-f":
                        try
                        {
                            DatabaseLocation = args[i + 1];
                            databaseSaveTextBox.Text = DatabaseLocation;
                        }
                        catch
                        {
                           error += "Unable to set database save location";
                        }
                        break;
                    case "-t":
                        try
                        {
                            serverTimeout = int.Parse(args[i + 1]);
                        }
                        catch
                        {
                            error += "Unable to set timeout";
                        }
                        break;
                    case "-d":
                        {
                            Debugger.Launch();
                        }
                        break;
                }
                if(error != "")
                {
                    MessageBox.Show(error);
                }
            }
            Log = new Logging(filename);
            if (File.Exists(DatabaseLocation))
            {
                StreamReader databaseLoad = new StreamReader(DatabaseLocation);
                MessageBox.Show("Successfully loaded database from: " + DatabaseLocation);
                while (databaseLoad.Peek() >= 0)
                {
                    userAndLocation = databaseLoad.ReadLine();
                    addUser = userAndLocation.Split(new char[] { ' ' }, 2)[0];
                    addLocation = userAndLocation.Split(new char[] { ' ' }, 2)[1];
                    Program.userLocations.Add(addUser, addLocation);
                }
                databaseLoad.Close();
            }
        }

        private void runServerButton_Click(object sender, EventArgs e)
        {
            serverStatus.Text = "Server: Running";
            serverStatus.ForeColor = Color.Green;
            serverStatus.Update();
            TcpListener listener;
            Socket connection;
            Handler RequestHandler;
            try
            {
                listener = new TcpListener(IPAddress.Any, 43);
                listener.Start();

                while (true)
                {
                    RefreshListBox();
                    connection = listener.AcceptSocket();
                    RequestHandler = new Handler();
                    Thread t = new Thread(() => RequestHandler.doRequest(connection, Log));
                    t.Start();
                    RefreshListBox();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.ToString());
            }
        }
        private void stopServerButton_Click(object sender, EventArgs e)
        {
        }
        public void RefreshListBox()
        {
            logListBox.Items.Clear();
            for (int i = 0; i < Program.logList.Count; i++)
            {
                logListBox.Items.Add(Program.logList[i]);
            }
            logListBox.Update();
        }
    }
}