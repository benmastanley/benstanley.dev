﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace locationServerUI
{
    public static class Program
    {
        public static Dictionary<string, string> userLocations = new Dictionary<string, string>();
        public static Logging Log;
        public static string DatabaseLocation = null;
        public static int serverTimeout = 1000;
        public static List<string> logList = new List<string>();
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            string mode = "Console";
            for (int i = 0; i < args.Length; i++)
			{
                if(args[i] == "-w")
                {
                    mode = "GUI";
                    continue;
                }
			}
            if(mode == "GUI")
            {
                Console.WriteLine("Please do not close this window in order to keep the server running");
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1(args));
            }
            else
            {
                string userAndLocation;
                string addUser;
                string addLocation;

                string filename = null;
                for (int i = 0; i < args.Length; i++)
                {
                    switch (args[i])
                    {
                        case "-l":
                            try
                            {
                                filename = args[i + 1];
                            }
                            catch
                            {
                                Console.WriteLine("Invalid log location path name");
                            }
                            break;
                        case "-f":
                            try
                            {
                                DatabaseLocation = args[i + 1];
                            }
                            catch
                            {
                                Console.WriteLine("Invalid database location path name");
                            }
                            break;
                        case "-t":
                            try
                            {
                                serverTimeout = int.Parse(args[i + 1]);
                            }
                            catch
                            {
                                Console.WriteLine("Unable to set timeout");
                            }
                            break;
                        case "-d":
                            {
                                Debugger.Launch();
                            }
                            break;
                    }
                }
                Log = new Logging(filename);
                if (File.Exists(DatabaseLocation))
                {
                    StreamReader databaseLoad = new StreamReader(DatabaseLocation);
                    Console.WriteLine("Successfully loaded database from: " + DatabaseLocation);
                    while (databaseLoad.Peek() >= 0)
                    {
                        userAndLocation = databaseLoad.ReadLine();
                        addUser = userAndLocation.Split(new char[] { ' ' }, 2)[0];
                        addLocation = userAndLocation.Split(new char[] { ' ' }, 2)[1];
                        userLocations.Add(addUser, addLocation);
                    }
                    databaseLoad.Close();
                }
                runServer();
            }
        }
        public static void runServer()
        {
            TcpListener listener;
            Socket connection;
            Handler RequestHandler;
            try
            {
                listener = new TcpListener(IPAddress.Any, 43);
                listener.Start();
                Console.WriteLine("\r\nServer started listening");

                while (true)
                {
                    connection = listener.AcceptSocket();
                    RequestHandler = new Handler();
                    Thread t = new Thread(() => RequestHandler.doRequest(connection, Log));
                    t.Start();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
            }
        }
    }

    public class Handler
    {
        public void doRequest(Socket connection, Logging Log)
        {
            string Host = ((IPEndPoint)connection.RemoteEndPoint).Address.ToString();
            NetworkStream socketStream = new NetworkStream(connection);
            StreamReader sr;
            StreamWriter sw;
            sw = new StreamWriter(socketStream);
            sr = new StreamReader(socketStream);
            string error = "";
            string user = null;
            string newlocation = "";
            string location = "";
            List<string> lines = new List<string>();
            string line = null;
            string status = "OK";
            string ClientInput = "";
            int IndexOfBreak;
            try
            {
                if (Program.serverTimeout != 0)
                {
                    socketStream.WriteTimeout = 1000;
                    socketStream.ReadTimeout = 1000;
                }
                while (sr.Peek() >= 0)
                {
                    ClientInput += (char)sr.Read();
                }
                lines.AddRange(ClientInput.Split());

                IndexOfBreak = lines.IndexOf("");
                if ((lines[0] == "GET") && (lines[1] != ""))
                {
                    if (lines[2] == "HTTP/1.1") // HTTP 1.1 lookup
                    {
                        user = lines[1].Substring(7);
                        line = "GET " + user;

                        if (Program.userLocations.ContainsKey(user))
                        {
                            location = Program.userLocations[user];
                            sw.Write($"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n{location}\r\n");
                        }
                        else if (!(Program.userLocations.ContainsKey(user)))
                        {
                            sw.Write("HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n");
                            status = "NOT FOUND";
                        }
                        sw.Flush();
                    }
                    else if (lines[2] == "HTTP/1.0") // HTTP 1.0 lookup
                    {
                        user = lines[1].Substring(2);
                        line = "GET " + user;

                        if (Program.userLocations.ContainsKey(user))
                        {
                            location = Program.userLocations[user];
                            sw.Write("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n" + location + "\r\n");
                        }
                        else if (!(Program.userLocations.ContainsKey(user)))
                        {
                            sw.Write("HTTP/1.0 404 Not Found\r\nContent-Type: text/plain\r\n\r\n");
                            status = "NOT FOUND";
                        }
                        sw.Flush();
                    }
                    else    // HTTP 0.9 lookup
                    {
                        string temp = lines[1].Remove(1);
                        if (temp == "/")
                        {
                            user = lines[1].Substring(1);
                            line = "GET " + user;

                            if (Program.userLocations.ContainsKey(user))
                            {
                                location = Program.userLocations[user];
                                sw.Write($"HTTP/0.9 200 OK\r\nContent-Type: text/plain\r\n\r\n{location}\r\n");
                            }
                            else if (!(Program.userLocations.ContainsKey(user)))
                            {
                                sw.Write("HTTP/0.9 404 Not Found\r\nContent-Type: text/plain\r\n\r\n");
                                status = "NOT FOUND";
                            }
                            sw.Flush();
                        }

                        else // IS ACTUALLY A WHOIS UPDATE
                        {
                            user = lines[0];

                            if (lines.Count > 2)
                            {
                                newlocation = lines[1];
                                for (int i = 2; i < lines.Count - 1; i++)
                                {
                                    if (lines[i] != "")
                                    {
                                        newlocation += " ";
                                        newlocation += lines[i];
                                    }
                                }
                            }
                            line = "PUT " + user + " " + newlocation;
                            if (Program.userLocations.ContainsKey(user))
                            {
                                Program.userLocations[user] = newlocation.TrimEnd(' ');
                                sw.Write("OK\r\n");
                            }
                            else
                            {
                                Program.userLocations.Add(user, newlocation.TrimEnd(' '));
                                sw.Write("OK\r\n");
                            }
                            sw.Flush();
                        }
                    }
                }
                else if ((lines[0] == "POST") && (lines[1].Substring(0, 1) == "/"))
                {
                    if (lines[2] == "HTTP/1.1") //HTTP 1.1 UPDATE
                    {
                        int lastLineIndex = 12;
                        for (int i = 5; i < lines.Count; i++)
                        {
                            if (lines[i].Contains("name="))
                            {
                                lastLineIndex = i;
                            }
                        }
                        string lastline = lines[lastLineIndex];
                        int userEnd = (lastline.IndexOf("location")) - 1;
                        int userLength = (userEnd - 5);
                        int locationStart = (lastline.IndexOf("location") + 9);
                        user = lastline.Substring(5, userLength);
                        try
                        {
                            newlocation = lastline.Substring(locationStart);
                            for (int i = lastLineIndex + 1; i < lines.Count; i++)
                            {
                                if (lines[i] == "")
                                {
                                    break;
                                }
                                else
                                {
                                    newlocation += " ";
                                    newlocation += lines[i];
                                }
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Unable to read location from client input");
                        }
                        line = "PUT " + user + " " + newlocation;
                        if (Program.userLocations.ContainsKey(user))
                        {
                            Program.userLocations[user] = newlocation;
                            sw.Write("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                        }
                        else if (!(Program.userLocations.ContainsKey(user)))
                        {
                            Program.userLocations.Add(user, newlocation);
                            sw.Write("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                        }
                        sw.Flush();
                    }


                    else if (lines[2] == "HTTP/1.0") //HTTP 1.0 UPDATE
                    {
                        int lastIndexOf = lines.LastIndexOf("");
                        user = lines[1].Substring(1);

                        newlocation = lines[9];
                        if (lines.Count > 10)
                        {
                            for (int i = 10; i < lines.Count; i++)
                            {
                                newlocation += " ";
                                newlocation += lines[i];
                            }

                        }
                        line = "PUT " + user + " " + newlocation;

                        if (Program.userLocations.ContainsKey(user))
                        {
                            Program.userLocations[user] = newlocation;
                            sw.Write("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                            sw.Flush();
                        }
                        else if (!(Program.userLocations.ContainsKey(user)))
                        {
                            Program.userLocations.Add(user, newlocation);
                            sw.Write("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                            sw.Flush();
                        }
                    }
                }
                else if ((lines[0] == "PUT") && (lines[1] != ""))  // HTTP 0.9 update
                {
                    string temp = lines[1].Remove(1);
                    if (temp == "/")
                    {
                        user = lines[1].Substring(1);
                        newlocation = lines[5];
                        for (int i = 6; i < lines.Count; i++)
                        {
                            if (lines[i] == "")
                            {
                                break;
                            }
                            else
                            {
                                newlocation += " ";
                                newlocation += lines[i];
                            }
                        }
                        line = "PUT " + user + " " + newlocation;

                        if (Program.userLocations.ContainsKey(user))
                        {
                            Program.userLocations[user] = newlocation;
                            sw.Write("HTTP/0.9 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                        }
                        else if (!(Program.userLocations.ContainsKey(user)))
                        {
                            Program.userLocations.Add(user, newlocation);
                            sw.Write("HTTP/0.9 200 OK\r\nContent-Type: text/plain\r\n\r\n");
                        }
                        sw.Flush();
                    }
                    else // IS ACTUALLY A WHOIS UPDATE
                    {
                        user = lines[0];
                        if (lines.Count > 2)
                        {
                            newlocation = lines[1];
                            for (int i = 2; i < lines.Count - 1; i++)
                            {
                                if (lines[i] != "")
                                {
                                    newlocation += " ";
                                    newlocation += lines[i];
                                }
                            }
                        }
                        line = "PUT " + user + " " + newlocation;

                        if (Program.userLocations.ContainsKey(user))
                        {
                            Program.userLocations[user] = newlocation.TrimEnd(' ');
                            sw.Write("OK\r\n");
                        }
                        else
                        {
                            Program.userLocations.Add(user, newlocation.TrimEnd(' '));
                            sw.Write("OK\r\n");
                        }
                        sw.Flush();
                    }
                }

                else // MUST BE WHOIS PROTOCOL  
                {
                    user = lines[0];
                    if (lines.Count > 2)
                    {
                        newlocation = lines[1];
                        for (int i = 2; i < lines.Count - 1; i++)
                        {
                            if (lines[i] != "")
                            {
                                newlocation += " ";
                                newlocation += lines[i];
                            }
                        }
                    }
                    if (Program.userLocations.ContainsKey(user))
                    {
                        if (newlocation == "") // WHOIS LOOKUP
                        {
                            line = "GET " + user;
                            sw.Write(Program.userLocations[user] + "\r\n");
                        }
                        else if (newlocation != "") // WHOIS UPDATE
                        {
                            line = "PUT " + user + " " + newlocation;

                            Program.userLocations[user] = newlocation.TrimEnd(' ');
                            sw.Write("OK\r\n");
                        }
                        sw.Flush();
                    }
                    else if (!(Program.userLocations.ContainsKey(user))) // user not found in dictionary
                    {
                        if (newlocation == "")
                        {
                            line = "GET " + user;

                            sw.Write("ERROR: no entries found\r\n");
                            status = "NOT FOUND";
                        }
                        else
                        {
                            line = "PUT " + user + " " + newlocation;

                            Program.userLocations.Add(user, newlocation.TrimEnd(' '));
                            sw.Write("OK\r\n");
                        }
                        sw.Flush();
                    }
                }
            }
            catch (Exception e)
            {
                if (error == "")
                {
                    error += e + " Server unable to handle request";
                }
                sw.WriteLine(error);
                sw.Flush();
                status = "EXCEPTION";
            }
            finally
            {
                socketStream.Close();
                connection.Close();
                Log.WriteToLog(Host, line, status);
            }
        }
    }

    public class Logging
    {
        public static string LogFile = null;
        public Logging(string Filename)
        {
            LogFile = Filename;
        }
        private static readonly object locker = new object();

        public void WriteToLog(string hostname, string message, string status)
        {
            string line = hostname + " - - " + DateTime.Now.ToString("'['dd'/'MM'/'yyyy':'HH':'mm':'ss zz00']'") + " \"" + message + "\" " + status;
            lock (locker)
            {
                Program.logList.Add(line);
                Console.WriteLine(line);
                Console.WriteLine();
                if (LogFile != null)
                {
                    try
                    {
                        StreamWriter sw;
                        sw = File.AppendText(LogFile);
                        sw.WriteLine(line);
                        sw.Close();
                    }
                    catch
                    {
                        Console.WriteLine("Unable to write Log File " + LogFile);
                    }
                }

                try      // WRITE USERS AND LOCATIONS TO DATABASE
                {
                    StreamWriter databaseSave;
                    if (Program.DatabaseLocation != null)
                    {
                        databaseSave = new StreamWriter(Program.DatabaseLocation);
                        Console.WriteLine("Databse saved to: " + Program.DatabaseLocation);
                        foreach (KeyValuePair<string, string> entry in Program.userLocations)
                        {
                            databaseSave.WriteLine(entry.Key + " " + entry.Value);
                        }
                        databaseSave.Close();
                    }
                }
                catch
                {
                    Console.WriteLine("Unable to save database");
                }
            }
        }
    }
}