﻿namespace locationServerUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.databaseSaveLabel = new System.Windows.Forms.Label();
            this.logSaveLabel = new System.Windows.Forms.Label();
            this.timeoutLabel = new System.Windows.Forms.Label();
            this.logListBox = new System.Windows.Forms.ListBox();
            this.databaseSaveTextBox = new System.Windows.Forms.TextBox();
            this.LogSaveTextBox = new System.Windows.Forms.TextBox();
            this.timeoutTextBox = new System.Windows.Forms.TextBox();
            this.runServerButton = new System.Windows.Forms.Button();
            this.serverStatus = new System.Windows.Forms.Label();
            this.EnableDebugging = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // databaseSaveLabel
            // 
            this.databaseSaveLabel.AutoSize = true;
            this.databaseSaveLabel.Location = new System.Drawing.Point(48, 35);
            this.databaseSaveLabel.Name = "databaseSaveLabel";
            this.databaseSaveLabel.Size = new System.Drawing.Size(122, 13);
            this.databaseSaveLabel.TabIndex = 0;
            this.databaseSaveLabel.Text = "Database save location:";
            // 
            // logSaveLabel
            // 
            this.logSaveLabel.AutoSize = true;
            this.logSaveLabel.Location = new System.Drawing.Point(76, 75);
            this.logSaveLabel.Name = "logSaveLabel";
            this.logSaveLabel.Size = new System.Drawing.Size(94, 13);
            this.logSaveLabel.TabIndex = 1;
            this.logSaveLabel.Text = "Log save location:";
            // 
            // timeoutLabel
            // 
            this.timeoutLabel.AutoSize = true;
            this.timeoutLabel.Location = new System.Drawing.Point(94, 116);
            this.timeoutLabel.Name = "timeoutLabel";
            this.timeoutLabel.Size = new System.Drawing.Size(70, 13);
            this.timeoutLabel.TabIndex = 2;
            this.timeoutLabel.Text = "Timeout (ms):";
            // 
            // logListBox
            // 
            this.logListBox.FormattingEnabled = true;
            this.logListBox.Location = new System.Drawing.Point(12, 173);
            this.logListBox.Name = "logListBox";
            this.logListBox.Size = new System.Drawing.Size(551, 186);
            this.logListBox.TabIndex = 3;
            // 
            // databaseSaveTextBox
            // 
            this.databaseSaveTextBox.Location = new System.Drawing.Point(176, 32);
            this.databaseSaveTextBox.Name = "databaseSaveTextBox";
            this.databaseSaveTextBox.Size = new System.Drawing.Size(100, 20);
            this.databaseSaveTextBox.TabIndex = 4;
            // 
            // LogSaveTextBox
            // 
            this.LogSaveTextBox.Location = new System.Drawing.Point(176, 72);
            this.LogSaveTextBox.Name = "LogSaveTextBox";
            this.LogSaveTextBox.Size = new System.Drawing.Size(100, 20);
            this.LogSaveTextBox.TabIndex = 5;
            // 
            // timeoutTextBox
            // 
            this.timeoutTextBox.Location = new System.Drawing.Point(176, 113);
            this.timeoutTextBox.Name = "timeoutTextBox";
            this.timeoutTextBox.Size = new System.Drawing.Size(100, 20);
            this.timeoutTextBox.TabIndex = 6;
            this.timeoutTextBox.Text = "1000";
            // 
            // runServerButton
            // 
            this.runServerButton.Location = new System.Drawing.Point(365, 43);
            this.runServerButton.Name = "runServerButton";
            this.runServerButton.Size = new System.Drawing.Size(147, 74);
            this.runServerButton.TabIndex = 7;
            this.runServerButton.Text = "Run Server";
            this.runServerButton.UseVisualStyleBackColor = true;
            this.runServerButton.Click += new System.EventHandler(this.runServerButton_Click);
            // 
            // serverStatus
            // 
            this.serverStatus.AutoSize = true;
            this.serverStatus.Location = new System.Drawing.Point(394, 24);
            this.serverStatus.Name = "serverStatus";
            this.serverStatus.Size = new System.Drawing.Size(0, 13);
            this.serverStatus.TabIndex = 9;
            // 
            // EnableDebugging
            // 
            this.EnableDebugging.AutoSize = true;
            this.EnableDebugging.Location = new System.Drawing.Point(176, 141);
            this.EnableDebugging.Name = "EnableDebugging";
            this.EnableDebugging.Size = new System.Drawing.Size(114, 17);
            this.EnableDebugging.TabIndex = 11;
            this.EnableDebugging.Text = "Enable Debugging";
            this.EnableDebugging.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Server Log:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(575, 371);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EnableDebugging);
            this.Controls.Add(this.serverStatus);
            this.Controls.Add(this.runServerButton);
            this.Controls.Add(this.timeoutTextBox);
            this.Controls.Add(this.LogSaveTextBox);
            this.Controls.Add(this.databaseSaveTextBox);
            this.Controls.Add(this.logListBox);
            this.Controls.Add(this.timeoutLabel);
            this.Controls.Add(this.logSaveLabel);
            this.Controls.Add(this.databaseSaveLabel);
            this.Name = "Form1";
            this.Text = "Server";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label databaseSaveLabel;
        private System.Windows.Forms.Label logSaveLabel;
        private System.Windows.Forms.Label timeoutLabel;
        private System.Windows.Forms.TextBox databaseSaveTextBox;
        private System.Windows.Forms.TextBox LogSaveTextBox;
        private System.Windows.Forms.TextBox timeoutTextBox;
        private System.Windows.Forms.Button runServerButton;
        private System.Windows.Forms.Label serverStatus;
        private System.Windows.Forms.CheckBox EnableDebugging;
        private System.Windows.Forms.ListBox logListBox;
        private System.Windows.Forms.Label label1;
    }
}

