<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php
$servername = "sql.rde.hull.ac.uk"; $ConnectionOptions = array("Database"=>"rde_538804");
$Conn = sqlsrv_connect( $servername, $ConnectionOptions);
if( $Conn === false )
{
echo "<br \><p align=\"center\">Connection failed.<br />";
die( print_r( sqlsrv_errors(), true));
}
else
{
echo "<br \><p align=\"center\">Connection to your SQL database succeeded.</p><br />";
}
phpinfo();
?>
</body>
</html>