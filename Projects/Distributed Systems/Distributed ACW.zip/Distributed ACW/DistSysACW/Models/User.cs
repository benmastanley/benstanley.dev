﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace DistSysACW.Models
{
    public class User
    {
        #region Task2
        // TODO: Create a User Class for use with Entity Framework
        // Note that you can use the [key] attribute to set your ApiKey Guid as the primary key 
        #endregion
        public User() { }
        [Key]
        public string ApiKey { get; set; }
        public string UserName { get; set; }
        public string Role { get; set; }
        //public ICollection<Log> Logs { get; set; }
        public virtual ICollection<Log> Logs { get; set; }
    }
    public class Log
    {
        public Log() { }
        [Key]
        public string LogId { get; set; }
        public string LogString { get; set; }
        public DateTime LogDateTime { get; set; }
        [ForeignKey("User")]
        public string UserId { get; set; }
    }
    public class LogArchive
    {
        public LogArchive() {  }
        [Key]
        public string LogArchiveId { get; set; }
        [ForeignKey("UserApiKey")]
        public string ApiKey { get; set; }
        [ForeignKey("LogId")]
        public string LogId { get; set; }
    }

    #region Task13?
    // TODO: You may find it useful to add code here for Logging
    #endregion

    public static class UserDatabaseAccess
    {
        #region Task3 
        // TODO: Make methods which allow us to read from/write to the database 
        #endregion
        public static void AddLog(string pMessage, string pApiKey, UserContext pContext)
        {
            User user = returnUser(pContext, pApiKey);

            Log log = new Log() { LogString = pMessage, LogDateTime = DateTime.Now };
            pContext.Logs.Add(log);

            if(user.Logs == null)
            {
                user.Logs = new List<Log>();
            }
            user.Logs.Add(log);

            LogArchive logArchive = new LogArchive()
            {
                LogId = log.LogId,
                ApiKey = pApiKey,
            };
            pContext.LogArchives.Add(logArchive);
            
            pContext.SaveChanges();
        }

        public static string newUser(UserContext pContext, String pUsername)
        {
            Guid obj = Guid.NewGuid();
            
            bool ApiExists = true; // set as true to check at least once
            while (ApiExists == true)
            {
                ApiExists = checkApiExists(pContext, obj.ToString());
                if (ApiExists == true)
                {
                    obj = Guid.NewGuid();
                }
            }
            string role = "User";
            if (containsAdmin(pContext) == false)
            {
                role = "Admin"; // If no admin in system, grant new user as admin
            }
            User u = new User()
            {
                UserName = pUsername,
                ApiKey = obj.ToString(),
                Role = role,
                Logs = new List<Log>()
            };
            pContext.Users.Add(u);
            pContext.SaveChanges();
            return obj.ToString();
        }

        public static bool checkApiExists(UserContext pContext, string pApiKey)
        {
            foreach(User user in pContext.Users)
            {
                if(user.ApiKey == pApiKey) // Check for ApiKey
                {
                    return true; 
                }
            }
            return false;
        }

        public static bool checkUsernameExists(UserContext pContext, string pUsername)
        {
            foreach (User user in pContext.Users)
            {
                if (user.UserName == pUsername) // Check for ApiKey and Username
                {
                    return true;
                }
            }
            return false;
        }

        public static bool checkExists(UserContext pContext, string pApiKey, string pUsername)
        {
            foreach(User user in pContext.Users)
            {
                if( (user.ApiKey == pApiKey) && (user.UserName == pUsername)) // Check for ApiKey and Username
                {
                    return true;
                }
            }
            return false;
        }

        //4. Check if a user with a given ApiKey string exists in the database, returning the User object.
        public static User returnUser(UserContext pContext, string pApiKey)
        {
            foreach (User user in pContext.Users)
            {
                if (user.ApiKey == pApiKey) // Check for ApiKey
                {
                    return user;
                }
            }
            return null;
        }

        //5. Delete a user with a given ApiKey from the database.
        public static void deleteUser(UserContext pContext, string pApiKey)
        {
            User u = returnUser(pContext, pApiKey);
            u = pContext.Users.Find(u.ApiKey);
            pContext.Users.Remove(u);
            pContext.SaveChanges();
        }

        private static bool containsAdmin(UserContext pContext)
        {
            foreach (User user in pContext.Users)
            {
                if (user.Role == "Admin") // Check for Admin
                {
                    return true;
                }
            }
            return false; //If no admin in system, return false
        }

        public static void ChangeRole(UserContext pContext, string pUsername, string pRole)
        {
            User user = pContext.Users.FirstOrDefault(u => u.UserName == pUsername); //TODO - Refactor other methods to this instead of foreach
            user.Role = pRole;
            pContext.SaveChanges();
        }
    }
}