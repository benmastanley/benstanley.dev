﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DistSysACW.Models;
using System.Security.Cryptography;
using DistSysACW.Singleton;
using CoreExtensions;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using System.IO;

namespace DistSysACW.Controllers
{
    public class ProtectedController : BaseController
    {
        public ProtectedController(Models.UserContext context) : base(context) { }

        [ActionName("Hello")]
        [HttpGet]
        public IActionResult Hello([FromHeader(Name ="ApiKey")] string ApiKey)
        {
            if (UserDatabaseAccess.checkApiExists(_context, ApiKey))
            {
                UserDatabaseAccess.AddLog("User requested /Protected/Hello", ApiKey, _context);

                User u = UserDatabaseAccess.returnUser(_context, ApiKey);
                string username = u.UserName;
                return Ok("Hello " + username);
            }
            else
            {
                return BadRequest("Unable to complete request - ensure ApiKey is valid");
            }
        }

        [ActionName("SHA1")]
        [HttpGet]
        public IActionResult SHA1([FromHeader(Name = "ApiKey")] string ApiKey, [FromQuery] string Message)
        {
            if (UserDatabaseAccess.checkApiExists(_context, ApiKey))
            {
                if ((Message != null) && (Message.Trim() != " "))
                {
                    byte[] byteMessage = System.Text.Encoding.ASCII.GetBytes(Message);
                    SHA1 sha1Provider = new SHA1CryptoServiceProvider();
                    byte[] sha1ByteMessage = sha1Provider.ComputeHash(byteMessage);

                    string hexOutput = BitConverter.ToString(sha1ByteMessage);
                    hexOutput = hexOutput.Replace("-", "");
                    return StatusCode(200, hexOutput);
                }
                else // no message sumbitted
                {
                    return BadRequest("Bad Request");
                }
            }
            else // api not valid
            {
                return BadRequest("Unable to complete request - ensure ApiKey is valid");
            }
        }

        [ActionName("SHA256")]
        [HttpGet]
        public IActionResult SHA256([FromHeader(Name = "ApiKey")] string ApiKey, [FromQuery] string Message)
        {
            if (UserDatabaseAccess.checkApiExists(_context, ApiKey))
            {
                if ((Message != null) && (Message.Trim() != " "))
                {
                    byte[] byteMessage = System.Text.Encoding.ASCII.GetBytes(Message);
                    SHA256 sha256Provider = new SHA256CryptoServiceProvider();
                    byte[] sha256ByteMessage = sha256Provider.ComputeHash(byteMessage);

                    string hexOutput = BitConverter.ToString(sha256ByteMessage);
                    hexOutput = hexOutput.Replace("-", "");
                    return StatusCode(200, hexOutput);
                }
                else // no message sumbitted
                {
                    return BadRequest("Bad Request");
                }
            }
            else // api not valid
            {
                return BadRequest("Unable to complete request - ensure ApiKey is valid");
            }
        }

        [ActionName("GetPublicKey")]
        [HttpGet]
        public IActionResult GetPublicKey([FromHeader(Name ="ApiKey")] string ApiKey)
        {
            if(UserDatabaseAccess.checkApiExists(_context, ApiKey))
            {
                UserDatabaseAccess.AddLog("User requested /Protected/GetPublicKey", ApiKey, _context);
                return Ok(RSACryptoExtensions.ToXmlStringCore22(RSACryptoServiceSingleton.GetInstance().getRSA()));
            }
            else
            {
                return BadRequest("Api Key Does not exist");
            }
        }

        [ActionName("Sign")]
        [HttpGet]
        public IActionResult Sign([FromHeader(Name ="ApiKey")] string ApiKey, [FromQuery] string message)
        {
            
            if(UserDatabaseAccess.checkApiExists(_context, ApiKey))
            {
                UserDatabaseAccess.AddLog("User requested /Protected/Sign", ApiKey, _context);

                byte[] asciiByteArray = Encoding.ASCII.GetBytes(message);
                RSACryptoServiceProvider rsa = RSACryptoServiceSingleton.GetInstance().getRSA();
                var signedData = rsa.SignData(asciiByteArray, new SHA1CryptoServiceProvider());
                var hexString = BitConverter.ToString(signedData);
                return Ok(hexString);
            }
            else
            {
                return BadRequest("ApiKey does not exist in the database");
            }
        }

        [ActionName("AddFifty")]
        [HttpGet]
        [Authorize(Roles ="Admin")]
        public IActionResult AddFifty([FromHeader(Name ="ApiKey")] string ApiKey, [FromQuery(Name ="encryptedInteger")] string encryptedInteger, 
                    [FromQuery(Name = "encryptedSymKey")] string encryptedSymKey, [FromQuery(Name = "encryptedIV")] string encryptedIV)
        {
            try
            {
                if (UserDatabaseAccess.checkApiExists(_context, ApiKey))
                {
                    UserDatabaseAccess.AddLog("User requested /Protected/AddFifty", ApiKey, _context);
                    byte[] IntByte, SymKeyByte, IVByte;
                    // convert from hex to Byte
                    IntByte = StringToByteArray(encryptedInteger);
                    SymKeyByte = StringToByteArray(encryptedSymKey);
                    IVByte = StringToByteArray(encryptedIV);

                    // decrypt using RSA key
                    RSACryptoServiceProvider rsa = RSACryptoServiceSingleton.GetInstance().getRSA();
                    IntByte = rsa.Decrypt(IntByte, true);
                    SymKeyByte = rsa.Decrypt(SymKeyByte, true);
                    IVByte = rsa.Decrypt(IVByte, true);

                    // From byte to string
                    string numberAsString = Encoding.ASCII.GetString(IntByte, 0, IntByte.Length);

                    // Add 50 to the integer
                    int number = int.Parse(numberAsString);
                    number = number + 50;
                    string returnNumber = number.ToString();

                    // Encrypt this integer using AES key and IV
                    AesCryptoServiceProvider aesProvider = new AesCryptoServiceProvider();
                    aesProvider.Key = SymKeyByte;
                    aesProvider.IV = IVByte;
                    byte[] encryptedByteNumber;
                    ICryptoTransform encryptor = aesProvider.CreateEncryptor();
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter sw = new StreamWriter(cs))
                            {
                                sw.Write(returnNumber);
                            }
                            encryptedByteNumber = ms.ToArray();
                        }
                    }

                    // Return int as hex string
                    var hexString = BitConverter.ToString(encryptedByteNumber);

                    return Ok(hexString);
                }
                else
                {
                    return BadRequest("ApiKey does not exist in the database");
                }
            }
            catch (Exception)
            {
                return BadRequest("An error occurred!");
            }
            
        }

        public static byte[] StringToByteArray(string hex)
        {
            hex = hex.Replace("-", "");
            return Enumerable.Range(0, hex.Length)
                .Where(x => x % 2 == 0)
                .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                .ToArray();
        }
    }
}