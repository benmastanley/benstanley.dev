﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DistSysACW.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authorization;

namespace DistSysACW.Controllers
{

    public class UserController : BaseController
    {
        /// <summary>
        /// Constructs a User controller, taking the UserContext through dependency injection
        /// </summary>
        /// <param name="context">DbContext set as a service in Startup.cs and dependency injected</param>
        public UserController(Models.UserContext context) : base(context) { }
        #region TASK4
        //TODO - add IactionResult methods which link correctly to the DB
        #endregion

        // /User/New GET request
        [ActionName("New")]
        [HttpGet]
        public IActionResult Get([FromQuery]string username)
        {
            if(username == null || username.Trim() == "")
            {
                return Ok("False - User Does Not Exist! Did you mean to do a POST to create a new user?");
            }
            else if ((UserDatabaseAccess.checkUsernameExists(_context, username)) == true)
            {
                return Ok("True - User Does Exist! Did you mean to do a POST to create a new user?");
            }
            else
            {
                return Ok("False - User Does Not Exist! Did you mean to do a POST to create a new user?");
            }
        }


        // /User/New POST request
        [ActionName("New")]
        [HttpPost]
        public IActionResult Post([FromBody]string username) //TODO: takes json string parameter from the body
        {
            try
            {
                if ((username == null) || (username.Trim() == "") || (username.Length == 0))
                {
                    return BadRequest("Oops. Make sure your body contains a string with your username" +
                        " and your Content - Type is Content - Type:application / json");
                }
                else if ((UserDatabaseAccess.checkUsernameExists(_context, username)) == true) //Username already exists
                {
                    return StatusCode(403, "Oops. This username is already in use. Please try again with a new username.");
                }
                else
                {
                    string apiKey = UserDatabaseAccess.newUser(_context, username);
                    return Ok(apiKey);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.ToString());
            }
        }

        // /User/RemoveUser DELETE request
        [ActionName("RemoveUser")]
        [HttpDelete]
        public Boolean Delete([FromHeader] string ApiKey, [FromQuery] string username)
        {
            if(UserDatabaseAccess.checkApiExists(_context, ApiKey) == true) // Api in database
            {
                User u = UserDatabaseAccess.returnUser(_context, ApiKey);
                if(username == u.UserName) // username matches api in database
                {
                    UserDatabaseAccess.AddLog("User requested /User/RemoveUser", ApiKey, _context);
                    UserDatabaseAccess.deleteUser(_context, ApiKey);
                    StatusCode(200);
                    return true;
                }
            }
            StatusCode(200);
            return false;
        }

        // /User/ChangeRole 
        [Authorize(Roles="Admin")]
        [ActionName("ChangeRole")]
        [HttpPost]
        public IActionResult ChangeRole([FromHeader] string ApiKey, [FromBody] Object j) 
        {
            User U = JsonConvert.DeserializeObject<User>(j.ToString());
            string username = U.UserName;
            string role = U.Role;
            
            if (UserDatabaseAccess.checkUsernameExists(_context, username) == false)
            {
                return BadRequest("NOT DONE: Username does not exist");
            }
            else if( (role != "User") && (role != "Admin"))
            {
                return BadRequest("NOT DONE: Role does not exist");
            }

            try
            {
                UserDatabaseAccess.AddLog("User requested /User/ChangeRole", ApiKey, _context);
                UserDatabaseAccess.ChangeRole(_context, username, role);
                return Ok("DONE");
            }
            catch (Exception)
            {
                return BadRequest("NOT DONE: An error occured");
            }
        }
    }
}