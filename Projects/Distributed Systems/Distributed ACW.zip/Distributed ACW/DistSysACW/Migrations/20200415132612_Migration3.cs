﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DistSysACW.Migrations
{
    public partial class Migration3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Logs_LogArchives_LogArchiveApiKey",
                table: "Logs");

            migrationBuilder.DropIndex(
                name: "IX_Logs_LogArchiveApiKey",
                table: "Logs");

            migrationBuilder.DropColumn(
                name: "LogArchiveApiKey",
                table: "Logs");

            migrationBuilder.AddColumn<DateTime>(
                name: "LogDateTime",
                table: "LogArchives",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "LogId",
                table: "LogArchives",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LogString",
                table: "LogArchives",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LogDateTime",
                table: "LogArchives");

            migrationBuilder.DropColumn(
                name: "LogId",
                table: "LogArchives");

            migrationBuilder.DropColumn(
                name: "LogString",
                table: "LogArchives");

            migrationBuilder.AddColumn<string>(
                name: "LogArchiveApiKey",
                table: "Logs",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Logs_LogArchiveApiKey",
                table: "Logs",
                column: "LogArchiveApiKey");

            migrationBuilder.AddForeignKey(
                name: "FK_Logs_LogArchives_LogArchiveApiKey",
                table: "Logs",
                column: "LogArchiveApiKey",
                principalTable: "LogArchives",
                principalColumn: "ApiKey",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
