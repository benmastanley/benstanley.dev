﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DistSysACW.Migrations
{
    public partial class Migration5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Logs_Users_UserApiKey",
                table: "Logs");

            migrationBuilder.RenameColumn(
                name: "UserApiKey",
                table: "Logs",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Logs_UserApiKey",
                table: "Logs",
                newName: "IX_Logs_UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Logs_Users_UserId",
                table: "Logs",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "ApiKey",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Logs_Users_UserId",
                table: "Logs");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Logs",
                newName: "UserApiKey");

            migrationBuilder.RenameIndex(
                name: "IX_Logs_UserId",
                table: "Logs",
                newName: "IX_Logs_UserApiKey");

            migrationBuilder.AddForeignKey(
                name: "FK_Logs_Users_UserApiKey",
                table: "Logs",
                column: "UserApiKey",
                principalTable: "Users",
                principalColumn: "ApiKey",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
