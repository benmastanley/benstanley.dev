﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DistSysACW.Migrations
{
    public partial class Migration4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_LogArchives",
                table: "LogArchives");

            migrationBuilder.DropColumn(
                name: "LogDateTime",
                table: "LogArchives");

            migrationBuilder.DropColumn(
                name: "LogString",
                table: "LogArchives");

            migrationBuilder.AlterColumn<string>(
                name: "ApiKey",
                table: "LogArchives",
                nullable: true,
                oldClrType: typeof(string));

            migrationBuilder.AddColumn<string>(
                name: "LogArchiveId",
                table: "LogArchives",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_LogArchives",
                table: "LogArchives",
                column: "LogArchiveId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_LogArchives",
                table: "LogArchives");

            migrationBuilder.DropColumn(
                name: "LogArchiveId",
                table: "LogArchives");

            migrationBuilder.AlterColumn<string>(
                name: "ApiKey",
                table: "LogArchives",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LogDateTime",
                table: "LogArchives",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "LogString",
                table: "LogArchives",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_LogArchives",
                table: "LogArchives",
                column: "ApiKey");
        }
    }
}
