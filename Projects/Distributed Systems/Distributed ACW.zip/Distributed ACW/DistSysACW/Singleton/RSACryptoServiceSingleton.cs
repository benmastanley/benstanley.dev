﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using CoreExtensions;

namespace DistSysACW.Singleton
{
    public class RSACryptoServiceSingleton
    {
        private static RSACryptoServiceSingleton instance;
        public static RSACryptoServiceSingleton GetInstance()
        {
            if(instance == null)
            {
                instance = new RSACryptoServiceSingleton();
            }
            return instance;
        }
        private static RSACryptoServiceProvider rsaProvider = null;
        public RSACryptoServiceProvider getRSA()
        {
            if(rsaProvider == null)
            {
                //CspParameters cspParams = new CspParameters();
                //cspParams.Flags = CspProviderFlags.UseMachineKeyStore;
                //rsaProvider = new RSACryptoServiceProvider(cspParams);
                rsaProvider = new RSACryptoServiceProvider();
            }
            return rsaProvider;
        }

    }
}
