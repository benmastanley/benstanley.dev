﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using CoreExtensions;

//using System.Net.Http.HttpClient;

namespace DistSysACWClient
{
    #region Task 10 and beyond
    public class User
    {
        public string username;
        public string role;
    }

    class Client
    {
        static HttpClient client = new HttpClient();
        
        static string mApiKey;
        static string mUsername;
        static string input;
        static string XMLKey;

        static void Main(string[] args)
        {
            client.BaseAddress = new Uri("https://localhost:44307/");

            Console.WriteLine("Hello. What would you like to do?");
            input = Console.ReadLine();
            while (input.ToLower() != "exit")
            {
                Console.WriteLine("...please wait...");
                DetermineTask();
                Console.WriteLine("What would you like to do next?");
                input = Console.ReadLine();
                Console.Clear();
            }
        }

        private static void DetermineTask()
        {
            try
            {
                string[] splitInput = input.Split(" ");
                string controller = splitInput[0];

                switch (controller)
                {
                    case "TalkBack":
                        switch (splitInput[1])
                        {
                            case "Hello":
                                SayHello().Wait();
                                break;

                            case "Sort":
                                if(splitInput.Length >= 3)
                                {
                                    SortNumbers(splitInput[2]).Wait();
                                }
                                else
                                {
                                    SortNumbers("").Wait();
                                }
                                break;
                        }
                        break;

                    case "User":
                        string username = "";
                        if (splitInput.Length >= 3)
                        {
                            username = splitInput[2];
                        }
                        string role = "";
                        if(splitInput.Length == 4)
                        {
                            role = splitInput[3];
                        }
                        switch (splitInput[1])
                        {
                            case "Get":
                                GetUser(username).Wait();
                                break;

                            case "Post":
                                PostUser(username).Wait();
                                break;

                            case "Set":
                                string apiKey = splitInput[3];
                                SetUser(username, apiKey);
                                break;

                            case "Delete":
                                if((mApiKey == null)||(mUsername == null))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first");
                                }
                                else
                                {
                                    DeleteUser(mUsername, mApiKey).Wait();
                                }
                                break;

                            case "Role":
                                if ((mApiKey == null) || (mApiKey.Trim() == ""))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first!");
                                }
                                else
                                {
                                    var jobject = new User()
                                    {
                                        username = username,
                                        role = role
                                    };
                                    var data = JsonConvert.SerializeObject(jobject);
                                    var stringContent = new StringContent(data, Encoding.UTF8, "application/json");

                                    UserChangeRole(stringContent).Wait();
                                }
                                break;
                        }
                        break;

                    case "Protected":
                        string message = "";
                        if (splitInput.Length >= 3)
                        {
                            message = splitInput[2];
                        }
                        switch (splitInput[1])
                        {
                            case "Hello":
                                if ((mApiKey == null) || (mApiKey.Trim() == ""))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first");
                                }
                                else
                                {
                                    HelloProtected().Wait();
                                }
                                break;

                            case "SHA1":
                                if ((mApiKey == null) || (mApiKey.Trim() == ""))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first");
                                }
                                else
                                {
                                    HelloSHA1Protected(message).Wait();
                                }
                                break;

                            case "SHA256":
                                if ((mApiKey == null) || (mApiKey.Trim() == ""))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first");
                                }
                                else
                                {
                                    HelloSHA256Protected(message).Wait();
                                }
                                break;

                            case "Get":
                                if ((mApiKey == null) || (mApiKey.Trim() == ""))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first");
                                }
                                else
                                {
                                    GetPublicKeyProtected().Wait();
                                }
                                break;

                            case "Sign":
                                if ((mApiKey == null) || (mApiKey.Trim() == ""))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first");
                                }
                                else if (XMLKey == null || XMLKey.Trim() == "")
                                {
                                    Console.WriteLine("Client doesn't yet have the public key");
                                }
                                else
                                {
                                    SignProtected(message).Wait();
                                }
                                break;

                            case "AddFifty":
                                string number;
                                try
                                {
                                    number = splitInput[2];
                                    int.Parse(number);
                                }
                                catch
                                {
                                    Console.WriteLine("A valid Integer must be given");
                                    break;
                                }
                                if ((mApiKey == null) || (mApiKey.Trim() == ""))
                                {
                                    Console.WriteLine("You need to do a User Post or User Set first");
                                }
                                else if (XMLKey == null || XMLKey.Trim() == "")
                                {
                                    Console.WriteLine("Client doesn't yet have the public key");
                                }
                                else
                                {
                                    AddFifty(number).Wait();
                                }
                                break;
                        }
                        break;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Unable to handle request, ensure request has correct parameters and is in correct form");
            }
            
        }

        static async Task AddFifty(string pNumber)
        {
            try
            {
                if (XMLKey == null || XMLKey.Trim() == "")
                {
                    Console.WriteLine("Client doesn't yet have the public key");
                }
                else
                {
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                    string path = "api/protected/addfifty?";

                    RSACryptoServiceProvider ClientRSAProvider = new RSACryptoServiceProvider();
                    ClientRSAProvider.FromXmlStringCore22(XMLKey);

                    AesCryptoServiceProvider aesProvider = new AesCryptoServiceProvider();
                    aesProvider.GenerateKey(); // shared key
                    aesProvider.GenerateIV(); // IV

                    
                    //Step 1: get all the byte array values
                    byte[] IntByte, SymKeyByte, IVByte;
                    IntByte = Encoding.ASCII.GetBytes(pNumber);
                    SymKeyByte = aesProvider.Key;
                    IVByte = aesProvider.IV;

                    //Step 2: encrypt all the values using rsa
                    IntByte = ClientRSAProvider.Encrypt(IntByte, true);
                    SymKeyByte = ClientRSAProvider.Encrypt(SymKeyByte, true);
                    IVByte = ClientRSAProvider.Encrypt(IVByte, true);

                    //Step 3: Convert all values to hex strings
                    string IntHexString = BitConverter.ToString(IntByte);
                    string SymKeyHexString = BitConverter.ToString(SymKeyByte);
                    string IVHexString = BitConverter.ToString(IVByte);

                    path += "encryptedInteger=" + IntHexString + "&encryptedSymKey=" + SymKeyHexString
                        + "&encryptedIV=" + IVHexString;

                    Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                    var result = responseMessage.Result;
                    string response = await result.Content.ReadAsStringAsync();

                    if (result.IsSuccessStatusCode)
                    {
                        response = response.Replace("-", "");
                        byte[] numberReturned = StringToByteArray(response);

                        // decrypt using aes
                        string numberAsString;
                        ICryptoTransform decryptor = aesProvider.CreateDecryptor();
                        using (MemoryStream ms = new MemoryStream(numberReturned))
                        {
                            using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                            {
                                using (StreamReader sr = new StreamReader(cs))
                                {
                                    numberAsString = sr.ReadToEnd();
                                }
                            }
                        }
                        Console.WriteLine(numberAsString);
                    }
                    else if(result.StatusCode.ToString() == "Unauthorized")
                    {

                        Console.WriteLine(response);
                    }
                    else
                    {
                        Console.WriteLine("An error occured!");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        public static byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        }
        
        static async Task SignProtected(string pMessage)
        {
            try
            {
                if (XMLKey == null || XMLKey.Trim() == "")
                {
                    Console.WriteLine("Client doesn't yet have the public key");
                }
                else
                {
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                    string path = "api/protected/sign?message=" + pMessage;
                    Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                    var result = responseMessage.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var response = await result.Content.ReadAsStringAsync();
                        RSACryptoServiceProvider ClientRSAProvider = new RSACryptoServiceProvider();
                        ClientRSAProvider.FromXmlStringCore22(XMLKey);
                        byte[] originalByteArray = Encoding.ASCII.GetBytes(pMessage);
                        response = response.Replace("-", "");
                        byte[] signedByteArray = StringToByteArray(response);
                        bool verified = ClientRSAProvider.VerifyData(originalByteArray, 
                            new SHA1CryptoServiceProvider(), signedByteArray);
                        if (verified)
                        {
                            Console.WriteLine("Message was successfully signed");
                        }
                        else
                        {
                            Console.WriteLine("Message was not successfully signed");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Message was not successfully signed");
                    }
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
            
            
        }

        static async Task GetPublicKeyProtected()
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                string path = "api/protected/getpublickey";
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var result = responseMessage.Result;
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    if(response == null || response.Trim() == "" || response.Length == 0)
                    {
                        Console.WriteLine("Couldn't get the Public Key");
                    }
                    else
                    {
                        XMLKey = response;
                        Console.WriteLine("Got Public Key");
                    }
                }
                else
                {
                    Console.WriteLine("Couldn't get the Public Key");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task HelloProtected()
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                string path = "api/protected/hello";
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var result = responseMessage.Result;
                var response = await result.Content.ReadAsStringAsync();
                Console.WriteLine(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task HelloSHA1Protected(string pMessage)
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                string path = "api/protected/sha1?message=" + pMessage;
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var result = responseMessage.Result;
                var response = await result.Content.ReadAsStringAsync();
                Console.WriteLine(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task HelloSHA256Protected(string pMessage)
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                string path = "api/protected/sha256?message=" + pMessage;
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var result = responseMessage.Result;
                var response = await result.Content.ReadAsStringAsync();
                Console.WriteLine(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task DeleteUser(string pUsername, string pApiKey)
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                string path = "api/user/removeuser?username=" + pUsername;
                client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                Task<HttpResponseMessage> responseMessage = client.DeleteAsync(path);
                var result = responseMessage.Result;
                string response = await result.Content.ReadAsStringAsync();
                Console.WriteLine(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        private static void SetUser(string username, string apiKey)
        {
            mUsername = username;
            mApiKey = apiKey;
            Console.WriteLine("Stored");
        }

        static async Task PostUser(string pUsername)
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                string path = "api/user/new";
                
                var data = JsonConvert.SerializeObject(pUsername);
                var stringContent = new StringContent(data, Encoding.UTF8, "application/json");

                Task<HttpResponseMessage> responseMessage = client.PostAsync(path, stringContent);
                var result = responseMessage.Result;
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    mApiKey = response;
                    mUsername = pUsername;
                    Console.WriteLine("Got Api Key");
                }
                else
                {
                    var response = await result.Content.ReadAsStringAsync();
                    Console.WriteLine(response);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task GetUser(string pUsername)
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                string path = "api/user/new?username=" + pUsername;
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var result = responseMessage.Result;
                var response = await result.Content.ReadAsStringAsync();
                Console.WriteLine(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task SortNumbers(string numberString)
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                string path = "api/talkback/sort?";

                numberString = numberString.Trim('[', ']');
                string[] numbers = numberString.Split(',');
                for (int i = 0; i < numbers.Count(); i++)
                {
                    path += "integers=" + numbers[i];
                    if(i < numbers.Count() - 1)
                    {
                        path += "&";
                    }
                }
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var result = responseMessage.Result;
                var response = await result.Content.ReadAsStringAsync();
                Console.WriteLine(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
            
        }

        static async Task SayHello()
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                string path = "api/talkback/hello";
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var result = responseMessage.Result;
                if (result.IsSuccessStatusCode)
                {
                    string response = await result.Content.ReadAsStringAsync();
                    Console.WriteLine(response);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
            
        }

        static async Task UserChangeRole(HttpContent stringContent)
        {
            try
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("ApiKey", mApiKey);
                string path = "api/user/changerole";

                Task<HttpResponseMessage> responseMessage = client.PostAsync(path, stringContent);
                var result = responseMessage.Result;
                string response = await result.Content.ReadAsStringAsync();

                Console.WriteLine(response);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }
    }
    #endregion
}
