﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessLogic
{
    public class FillLine : Line
    {
        internal FillLine(FillPage page) : base(page)
        {
        }
        internal override int Length() // Method to check the character length of the current line
        { 
            int result = 0;
            for (int i = 0; i < content.Count; i++)
            {
                result += content[i].Length;
                if(i != content.Count - 1)
                {
                    result++;
                }
            }
            return result;
        }
        internal override bool Overflow() // Calls to see if overflow
        { 
            if (content.Count < 2)
            {
                return false;
            }
            return this.WrapOverflow();
        }
        internal bool WrapOverflow() // Checks if the length overflows the wrap
        { 
            return Length() > ((FillPage)page).wrap;
        }
        internal override void IntoText(StringBuilder text) // Converting line into text
        {
            foreach (String word in content)
            {
                text.Append(word.ToString());
                text.Append(" ");
            }
            text.Remove(text.Length - 1, 1);
        }
    }
}
