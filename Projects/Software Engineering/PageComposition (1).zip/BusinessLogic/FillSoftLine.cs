﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class FillSoftLine : Line
    {
        internal int wrap;
        internal int wrapSoft;
        internal int totalNumberOfLines;
        bool isLineSoftWrap;

        internal FillSoftLine(FillSoftPage page, int pWrap, int pWrapSoft, int pTotalNumberOfLines) : base(page)
        {
            totalNumberOfLines = pTotalNumberOfLines;
            wrap = pWrap;
            wrapSoft = pWrapSoft;
        }

        internal override int Length()
        {
            int result = 0;
            isLineSoftWrap = false;

            foreach (String word in content)
            {
                result += word.Length;
                result += 1;

                if (word.Length == ((FillSoftPage)page).wrap)   // if one word fits the entire wrap then take away the end space
                {
                    result -= 1;
                }
                if (page.content.Count <= totalNumberOfLines / 2)
                {
                    isLineSoftWrap = true;
                }
                if (result == ((FillSoftPage)page).wrap + 1)    // if multiple words fit the entire wrap then take away the end space
                {
                    result -= 1;
                }
            }
            return result;
        }

        internal override bool Overflow()
        {
            return this.WrapOverflow();
        }
        internal bool WrapOverflow()
        {
            if (isLineSoftWrap)
            {
                return Length() > ((FillSoftPage)page).wrapSoft;
            }
            else
            {
                return Length() > ((FillSoftPage)page).wrap;
            }
        }
        internal override void IntoText(StringBuilder text)
        {
            foreach (String word in content)
            {
                text.Append(word.ToString());
                text.Append(" ");
            }
            text.Remove(text.Length - 1, 1);
        }
    }
}
