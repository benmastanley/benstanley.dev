﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class FillSoftPage : Page
    {
        internal int wrap;
        internal int wrapSoft;
        internal int totalNumberOfLines;

        internal FillSoftPage(int wrap, int wrapSoft, int totalNumberOfLines)
        {
            this.totalNumberOfLines = totalNumberOfLines;
            this.wrapSoft = wrapSoft;
            this.wrap = wrap;
            content = new List<Line>();
            AddLine();
        }

        internal override void AddLine()
        {
            currentLine = new FillSoftLine(this, wrap, wrapSoft, totalNumberOfLines);
            totalNumberOfLines++;
            content.Add(currentLine);
        }

        internal override bool Overflow()
        {
            foreach (Line line in content)
            {
                if (line.Overflow())
                {
                    return true;
                }
            }
            return false;
        }
    }
}