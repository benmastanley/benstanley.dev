﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public enum Format { Fill, FillSoft, FillAdjust, LineMoment, FillSet };

    public class PageInput
    {
        char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
        char[] alphabet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' }; // for linemoment letter value (index + 1)
        public Format format;
        public int wrap = 0;
        public int wrapSoft = 0;
        public int columnMoment = 0;
        public List<String> words;
        public PageInput()
        {
            words = new List<String>();
        }
        public PageInput(Format format, int wrap, int wrapSoft, int columnMoment, List<String> words)
        {
            this.format = format;
            this.wrap = wrap;
            this.wrapSoft = wrapSoft;
            this.columnMoment = columnMoment;
            this.words = words;
        }
        public int returnVowelNumber(string word)
        {
            int numberofvowels = 0;
            for (int i = 0; i < word.Length; i++)
            {
                char c = word[i];
                if(vowels.Contains(c))
                {
                    numberofvowels++;
                }
            }
            return numberofvowels;
        }
        private int TotalNumberOfLines()    // works out the amount of lines that will be needed on the page
        {
            int lines = 0;
            int result = 0;

            for (int i = 0; i < words.Count; i++)
            {
                result += words[i].Length;
                result += 1;

                if (words[i].Length == wrap)
                {
                    result -= 1;
                }
                if (result == wrap + 1)
                {
                    result = 0;
                    lines++;
                }
                if (result > wrap)
                {
                    lines++;
                    result = 0;
                    i -= 1;
                }
                if (words.Count - 1 == i)
                {
                    if (result <= wrap)
                    {
                        lines++;
                    }
                    else
                    {
                        lines += 2;
                    }
                }

            }
            return lines;
        }
        public Page Compose()
        {
            switch (format)
            {
                case Format.Fill:
                    {
                        FillPage page = new FillPage(wrap); 
                        page.Add(words);                    
                      
                        return page;
                    }

                case Format.FillSoft:
                    {
                        FillSoftPage page = new FillSoftPage(wrap, wrapSoft, TotalNumberOfLines());
                        page.Add(words);
                        return page;
                    }

                case Format.FillAdjust:
                    {
                        FillPage page = new FillPage(wrap);
                        page.Add(words);
                        List<int> combinedVowels;
                        List<int> newList;

                        for (int i = 0; i < page.content.Count; i++) //For each line to be adjusted
                        {
                            Line line = page.content[i];
                            int remainingSpaces = (page.wrap - line.Length());

                            if (line.content.Count == 2)
                            {
                                while (remainingSpaces > 0)
                                {
                                    line.content[0] += " ";
                                    remainingSpaces--;
                                }
                            }
                            if (line.content.Count > 2)
                            {
                                combinedVowels = new List<int>();  // List for combined vowels of words next to each other, the nth index contains the vowel sum of the n and n+1 words.
                                for (int j = 0; j < (line.content.Count - 1); j++)
                                {
                                    combinedVowels.Add((returnVowelNumber(line.content[j]) + returnVowelNumber(line.content[j + 1])));
                                }
                                while (remainingSpaces > 0)
                                {
                                newList = combinedVowels;
                                    for (int k = 0; k < combinedVowels.Count; k++)
                                    {
                                        int highestIndex = newList.IndexOf(newList.Max()); // this is the index of the word that the space should be added after
                                        line.content[highestIndex] += " ";                                        
                                        newList.RemoveAt(highestIndex); // removes this from the new list     
                                        remainingSpaces--;
                                        if (remainingSpaces == 0)
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        return page;
                    }

                case Format.LineMoment:
                    {
                        FillPage page = new FillPage(wrap);
                        page.Add(words);
                        List<Line> lineList;

                        for (int i = 0; i < page.content.Count; i++) // For each line
                        {
                            lineList = new List<Line>(); // Create a list for all the possible variations of a line to find the one with the lowest line moment.
                            
                            Line line = page.content[i];
                            int lineMoment = 0;
                            int minMoment = 0;

                            for (int j = 0; j < line.content.Count; j++) // For each word
                            {
                                string word = line.content[j];
                                int numberOfChecks = wrap - line.content.Count;
                                int wordMoment = 0;

                                for (int k = 0; k < word.Length; k++) // For each character
                                {
                                    char c = word[k];
                                    int letterValue = (Array.IndexOf(alphabet, c)) + 1;
                                    string sLine = line.ToString();
                                    int indexOfWord = (sLine.IndexOf(word));
                                    int indexOfChar = (word.IndexOf(c));
                                    int indexOfLetter = indexOfWord + indexOfChar;
                                    int distanceOfLetter = indexOfLetter - columnMoment;
                                    int letterMoment = distanceOfLetter * letterValue; 
                                    wordMoment += letterMoment;
                                }
                                lineMoment += wordMoment;
                            }
                            line.lineMoment = lineMoment;
                            minMoment = lineMoment;
                            lineList.Add(line);

                            // CHECK ALL THE POSSIBLE VARIATIONS BY ADDING SPACES (USE A FOR LOOP ---- INT Z=0; Z <= NUMBER OF CHECKS; Z++ )
                            // ADD TO THE LINELIST AND MEASURE THE LINEMOMENT FOR EACH VARIATION
                            // GO THROUGH ALL THE CREATED VARIATIONS IN LINELIST, AND FOR THE VARIATION WITH THE MIN LINE MOMENT, SET THE PAGE.CONTENT[I] TO THIS LINE.


                            Line newLine = line; // create a line to store the line with the smallest linemoment value

                            for (int m = 0; m < lineList.Count; m++) // for all the lines in the linelist
                            {
                                if (minMoment > lineList[m].lineMoment) // set the newLine to current line iteration if it has smaller linemoment value 
                                {
                                    minMoment = lineList[m].lineMoment;
                                    newLine = lineList[m];
                                }
                                if (m == (lineList.Count-1)) // when the last value in the linelist has been reached, set the page.content line to the new variation
                                {
                                    page.content.Remove(line);
                                    page.content.Insert(i, newLine);
                                }
                            }
                        }
                        return page;
                    }


                case Format.FillSet:
                    {
                        FillPage page = new FillPage(wrap);
                        page.Add(words);

                        for (int x = 0; x < page.content.Count; x++) //Check all lines on page
                        {
                            int spacesAppending = (page.wrap - page.content[x].Length()) - 1; //calculate remaining spaces for current line

                            for (int j = spacesAppending; j > 0; j--) //Check for words that fit the space, if not decrement the word search size
                            {
                                for (int i = x+1; i < page.content.Count; i++) //Check each line after the line being filled
                                {
                                    Line line = page.content[i];
                                    for (int z = 0; z < line.content.Count; z++) //Check each word on the line for a match
                                    {
                                        string word = line.content[z];
                                        if (word.Length == j)
                                        {
                                            page.content[x].Add(word);
                                            page.content[i].Remove(word);
                                        }
                                    }
                                }
                            }
                        }
                        return page;
                    }

                default:
                    {
                        throw new Exception("Unknown format.");
                    }
            }
        }
    }
}
