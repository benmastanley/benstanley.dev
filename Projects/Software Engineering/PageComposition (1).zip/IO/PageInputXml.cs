﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Serialization;
using System.Diagnostics;
using BusinessLogic;
using System.Text.RegularExpressions;

namespace IO {
  public class PageInputXml {

    static String delimStr = " ";
    static char[] delimChars = delimStr.ToCharArray();
    static char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
    public static int numberOfVowels = 0;

        public static PageInput LoadInput(String pathname) {
      XmlDocument pagInputXml = new XmlDocument();
      try {
        using (TextReader reader = File.OpenText(pathname)) {
          pagInputXml.Load(reader);
        }
      }
      catch (Exception e) {
        Console.WriteLine(e.Message);
      }
      PageInput pageIn = new PageInput();
      XmlNodeList formatnl = pagInputXml.SelectNodes("//pageinput/format");
      if (formatnl.Count == 1) {
        String formatstr = formatnl[0].FirstChild.Value;
        switch (formatstr) {
          case "Fill": {
              pageIn.format = Format.Fill;
              break;
            }
          case "FillSoft": {
              pageIn.format = Format.FillSoft;
              break;
            }
          case "FillAdjust": {
              pageIn.format = Format.FillAdjust;
              break;
            }
          case "LineMoment": {
              pageIn.format = Format.LineMoment;
              break;
            }
          case "FillSet": {
              pageIn.format = Format.FillSet;
              break;
            }
          default: {
              throw new Exception("Unknown format: " + formatstr);
            }
        }
      }
      else {
        throw new Exception("Xml error");
      }
      XmlNodeList wrapnl = pagInputXml.SelectNodes("//pageinput/wrap");
      if (wrapnl.Count == 1) {
        pageIn.wrap = Int32.Parse(wrapnl[0].InnerText);
      }
      else {
        throw new Exception("Xml error");
      }
      XmlNodeList wrapsoftnl = pagInputXml.SelectNodes("//pageinput/wrapsoft");
      if (wrapsoftnl.Count == 1) {
        pageIn.wrapSoft = Int32.Parse(wrapsoftnl[0].InnerText);
      }
      else {
        throw new Exception("Xml error");
      }
      XmlNodeList columnmomentnl = pagInputXml.SelectNodes("//pageinput/columnmoment");
      if (columnmomentnl.Count == 1) {
        pageIn.columnMoment = Int32.Parse(columnmomentnl[0].InnerText);
      }
      else {
        throw new Exception("Xml error");
      }
      XmlNodeList wordsnl = pagInputXml.SelectNodes("//pageinput/words");
      String text = wordsnl[0].InnerText;
        String[] textParts;
        textParts = text.Split(delimChars);

        for (int i = 0; i < textParts.Length; i++ ) { // validation to see if input string qualifies as a word
          String s = textParts[i];
                if((s.Trim() != "") && (s == s.ToLower())) //check if string is empty or if has upper case letters
                {
                    if (isValid(s) && vowelsInOrder(s)) //check if contains only a-z characters, and that the vowels are in order
                    {
                        if(s.Length <= 3 && numberOfVowels >= 1) //if s is of length 3 or less, it must contain at least one vowel
                        {
                            pageIn.words.Add(s);
                        }
                        else if(s.Length > 3 && numberOfVowels >= 2) //if s is of length greater than 3, it must contain at least two vowels
                        {
                            pageIn.words.Add(s);
                        }
                    }
                }
                numberOfVowels = 0;
        }
      return pageIn;
    }
        public static bool isValid(string s)
        {
            return Regex.IsMatch(s, @"^[a-z]+$");
        }
        public static bool vowelsInOrder(string s)
        {
            int lastIndex = -1;
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                int vowelIndex = Array.IndexOf(vowels, c);
                if(vowelIndex >= 0)
                {
                    numberOfVowels += 1;
                    if (vowelIndex < lastIndex)
                    {
                        return false;
                    }
                    else
                        lastIndex = vowelIndex;
                }
            }
            return true;
        }
    }
}
