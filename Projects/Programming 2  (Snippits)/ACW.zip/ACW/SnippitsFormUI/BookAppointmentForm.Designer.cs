﻿namespace SnippitsFormUI
{
    partial class BookAppointmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.stylistComboBox = new System.Windows.Forms.ComboBox();
            this.availableAppointmentsListBox = new System.Windows.Forms.ListBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.bookAppointmentButton = new System.Windows.Forms.Button();
            this.appointmentLengthComboBox = new System.Windows.Forms.ComboBox();
            this.durationLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(17, 16);
            this.dateTimePicker.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(265, 22);
            this.dateTimePicker.TabIndex = 0;
            this.dateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker_ValueChanged);
            // 
            // stylistComboBox
            // 
            this.stylistComboBox.FormattingEnabled = true;
            this.stylistComboBox.Location = new System.Drawing.Point(293, 16);
            this.stylistComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.stylistComboBox.Name = "stylistComboBox";
            this.stylistComboBox.Size = new System.Drawing.Size(217, 24);
            this.stylistComboBox.TabIndex = 1;
            this.stylistComboBox.SelectedIndexChanged += new System.EventHandler(this.stylistComboBox_SelectedIndexChanged);
            // 
            // availableAppointmentsListBox
            // 
            this.availableAppointmentsListBox.FormattingEnabled = true;
            this.availableAppointmentsListBox.ItemHeight = 16;
            this.availableAppointmentsListBox.Location = new System.Drawing.Point(17, 49);
            this.availableAppointmentsListBox.Margin = new System.Windows.Forms.Padding(4);
            this.availableAppointmentsListBox.Name = "availableAppointmentsListBox";
            this.availableAppointmentsListBox.Size = new System.Drawing.Size(493, 292);
            this.availableAppointmentsListBox.TabIndex = 2;
            // 
            // cancelButton
            // 
            this.cancelButton.AutoSize = true;
            this.cancelButton.Location = new System.Drawing.Point(411, 351);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(100, 28);
            this.cancelButton.TabIndex = 3;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // bookAppointmentButton
            // 
            this.bookAppointmentButton.Location = new System.Drawing.Point(251, 350);
            this.bookAppointmentButton.Margin = new System.Windows.Forms.Padding(4);
            this.bookAppointmentButton.Name = "bookAppointmentButton";
            this.bookAppointmentButton.Size = new System.Drawing.Size(152, 28);
            this.bookAppointmentButton.TabIndex = 4;
            this.bookAppointmentButton.Text = "Book Appointment";
            this.bookAppointmentButton.UseVisualStyleBackColor = true;
            this.bookAppointmentButton.Click += new System.EventHandler(this.bookAppointmentButton_Click);
            // 
            // appointmentLengthComboBox
            // 
            this.appointmentLengthComboBox.FormattingEnabled = true;
            this.appointmentLengthComboBox.Items.AddRange(new object[] {
            "00:30:00",
            "01:00:00"});
            this.appointmentLengthComboBox.Location = new System.Drawing.Point(87, 351);
            this.appointmentLengthComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.appointmentLengthComboBox.Name = "appointmentLengthComboBox";
            this.appointmentLengthComboBox.Size = new System.Drawing.Size(155, 24);
            this.appointmentLengthComboBox.TabIndex = 5;
            // 
            // durationLabel
            // 
            this.durationLabel.AutoSize = true;
            this.durationLabel.Location = new System.Drawing.Point(16, 356);
            this.durationLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.durationLabel.Name = "durationLabel";
            this.durationLabel.Size = new System.Drawing.Size(62, 17);
            this.durationLabel.TabIndex = 6;
            this.durationLabel.Text = "Duration";
            // 
            // BookAppointmentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(523, 385);
            this.Controls.Add(this.durationLabel);
            this.Controls.Add(this.appointmentLengthComboBox);
            this.Controls.Add(this.bookAppointmentButton);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.availableAppointmentsListBox);
            this.Controls.Add(this.stylistComboBox);
            this.Controls.Add(this.dateTimePicker);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BookAppointmentForm";
            this.Text = "Appointment Bookings";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.ComboBox stylistComboBox;
        private System.Windows.Forms.ListBox availableAppointmentsListBox;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button bookAppointmentButton;
        private System.Windows.Forms.ComboBox appointmentLengthComboBox;
        private System.Windows.Forms.Label durationLabel;
    }
}