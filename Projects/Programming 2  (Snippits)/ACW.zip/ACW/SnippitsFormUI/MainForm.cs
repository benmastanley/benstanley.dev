﻿using System;
using System.Windows.Forms;
using SnippitsBusinessLogic;
using System.Collections.Generic;
using System.IO;

namespace SnippitsFormUI
{
    public partial class MainForm : Form
    {
        // Creating new lists for Stylists and Customers 
        // Creating relevant dictionaries for chair bookings and then availability
        public static List<Stylist> sList = null;
        public static List<Customer> cList = null;
        public static Dictionary<DateTime, Stylist[]> chairs = new Dictionary<DateTime, Stylist[]>();
        public static Dictionary<Tuple<Stylist, DateTime>, List<DateTime>> Availability = new Dictionary<Tuple<Stylist, DateTime>, List<DateTime>>();

        public MainForm()
        {
            InitializeComponent();
            sList = new List<Stylist>();
            cList = new List<Customer>();
        }

        private void customersButton_Click(object sender, EventArgs e)
        {
            CustomerSelectionForm form = new CustomerSelectionForm();
            form.ShowDialog();
        }

        private void stylistsButton_Click(object sender, EventArgs e)
        {
            StylistSelectionForm form = new StylistSelectionForm();
            form.ShowDialog();
        }
    }
}
