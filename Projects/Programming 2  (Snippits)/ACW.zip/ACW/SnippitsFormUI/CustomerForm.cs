﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SnippitsBusinessLogic;

namespace SnippitsFormUI
{
    public partial class CustomerForm : Form
    {
        private Customer mCustomer = null;
        public Customer GetCustomer()
        {
            return mCustomer;
        }
        public CustomerForm()
        {
            InitializeComponent();
        }
        public CustomerForm(Customer _Customer) : this()
        {
            firstNameTextBox.Text = _Customer.Forename;
            surnameTextBox.Text = _Customer.Surname;
            emailTextBox.Text = _Customer.EmailAddress;
            phoneNumberTextBox.Text = _Customer.PhoneNumber;
            mCustomer = _Customer;
            DrawCustomerAppointmentsListBox();
        }
        private void DrawCustomerAppointmentsListBox()
        {
            appointmentsListBox.Items.Clear();
            for (int i = 0; i < mCustomer.CustomerAppointments.Count; i++)
            {
                appointmentsListBox.Items.Add(mCustomer.CustomerAppointments[i]);
            }
        }
        private void acceptButton_Click(object sender, EventArgs e)
        {
            string allErrors = "";

            if (mCustomer == null)
            {
                try
                {
                    mCustomer = new Customer(firstNameTextBox.Text, surnameTextBox.Text,
                        emailTextBox.Text, phoneNumberTextBox.Text);
                    MainForm.cList.Add(mCustomer);
                    MessageBox.Show("You've added a new customer");
                }
                catch (Exception ex)
                {
                    allErrors += ex.Message;
                }
            }
            else
            {
                string error = "";
                if (!(mCustomer.SetForename(firstNameTextBox.Text, out error)))
                {
                    allErrors += error;
                }
                if (!(mCustomer.SetSurname(surnameTextBox.Text, out error)))
                {
                    allErrors += error;
                }
                if (!(mCustomer.SetEmailAddress(emailTextBox.Text, out error)))
                {
                    allErrors += error;
                }
                if (!(mCustomer.SetPhoneNumber(phoneNumberTextBox.Text, out error)))
                {
                    allErrors += error;
                }
            }
            if (allErrors.Length == 0)
            {
                this.Close();
            }
            else
            {
                this.DialogResult = DialogResult.None;
                MessageBox.Show(allErrors);
            }
        }
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
