﻿using System;
using System.Windows.Forms;
using SnippitsBusinessLogic;

namespace SnippitsFormUI
{
    public partial class CustomerSelectionForm : Form
    {
        public CustomerSelectionForm()
        {
            InitializeComponent();
            DrawCustomerListBox();
        }
        private void addNewCustomerButton_Click(object sender, EventArgs e)
        {
            CustomerForm form = new CustomerForm();
            form.ShowDialog();
            if (form.DialogResult == DialogResult.OK)
            {
                DrawCustomerListBox();
            }
        }
        private void editCustomerButton_Click(object sender, EventArgs e)
        {
            if (CustomerListBox.SelectedItem == null)
            {
                MessageBox.Show("No customer selected");
            }
            else
            {
                Customer customer = (Customer)CustomerListBox.SelectedItem;
                CustomerForm form = new CustomerForm(customer);
                form.ShowDialog();
                if (form.DialogResult == DialogResult.OK)
                {
                    DrawCustomerListBox();
                }
            }
        }
        private void bookAppointmentButton_Click(object sender, EventArgs e)
        {
            if (CustomerListBox.SelectedItem == null)
            {
                MessageBox.Show("No customer selected");
            }
            else
            {
                Customer cust = (Customer)CustomerListBox.SelectedItem;
                BookAppointmentForm form = new BookAppointmentForm(cust);
                form.ShowDialog();
            }
        }
        private void DrawCustomerListBox()
        {
            CustomerListBox.Items.Clear();
            foreach (Customer C in MainForm.cList)
            {
                CustomerListBox.Items.Add(C);
            }
        }
        private void searchButton_Click(object sender, EventArgs e)
        {
            CustomerListBox.Items.Clear();
            foreach (Customer C in MainForm.cList)
            {
                if (($"{C.Forename.ToUpper()} {C.Surname.ToUpper()}").Contains(searchTextBox.Text.ToUpper()))
                {
                    CustomerListBox.Items.Add(C);
                }
            }
        }
    }
}
