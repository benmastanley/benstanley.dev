﻿using SnippitsBusinessLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace SnippitsFormUI
{
    public partial class StylistForm : Form
    {
        private Stylist mStylist = null;
        public Stylist GetStylist()
        {
            return mStylist;
        }
        public StylistForm()
        {
            InitializeComponent();
        }
        public StylistForm(Stylist _Stylist) : this()
        {
            DrawTransactionsListBox(_Stylist);
            firstNameTextBox.Text = _Stylist.Forename;
            surnameTextBox.Text = _Stylist.Surname;
            emailTextBox.Text = _Stylist.EmailAddress;
            textBox1.Text = _Stylist.PhoneNumber;
            hourlyRateTextBox.Text = _Stylist.HourlyRate.ToString();
            balanceLabel.Text = $"Stylist Account Balance £{_Stylist.StylistBalance}";
            mStylist = _Stylist;
        }
        private void DrawTransactionsListBox(Stylist _stylist)
        {
            transactionsListBox.Items.Clear();
            foreach (string transaction in _stylist.StylistTransactions)
            {
                transactionsListBox.Items.Add(transaction);
            }
        }
        private void acceptButton_Click(object sender, EventArgs e)
        {
            string allErrors = "";
            if (mStylist == null)
            {
                try
                {
                    mStylist = new Stylist(firstNameTextBox.Text, surnameTextBox.Text, emailTextBox.Text,
                    textBox1.Text, int.Parse(hourlyRateTextBox.Text));
                    MainForm.sList.Add(mStylist);
                    MessageBox.Show("You've added a new stylist");
                }
                catch (Exception ex)
                {
                    allErrors += ex.Message;
                }
            }
            else
            {
                string error = "";
                if (!(mStylist.SetForename(firstNameTextBox.Text, out error)))
                {
                    allErrors += error;
                }
                if (!(mStylist.SetSurname(surnameTextBox.Text, out error)))
                {
                    allErrors += error;
                }
                if (!(mStylist.SetEmailAddress(emailTextBox.Text, out error)))
                {
                    allErrors += error;
                }
                if (!(mStylist.SetPhoneNumber(textBox1.Text, out error)))
                {
                    allErrors += error;
                }
                if (!(mStylist.SetHourlyRate(int.Parse(hourlyRateTextBox.Text), out error)))
                {
                    allErrors += error;
                }
            }
            if (allErrors.Length == 0)
            {
                this.Close();
            }
            else
            {
                this.DialogResult = DialogResult.None;
                MessageBox.Show(allErrors);
            }
        }
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}