﻿namespace SnippitsFormUI
{
    partial class StylistSelectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.addNewStylistButton = new System.Windows.Forms.Button();
            this.editStylistButton = new System.Windows.Forms.Button();
            this.StylistListBox = new System.Windows.Forms.ListBox();
            this.bookChairButton = new System.Windows.Forms.Button();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(124, 15);
            this.searchTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(500, 22);
            this.searchTextBox.TabIndex = 9;
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(16, 11);
            this.searchButton.Margin = new System.Windows.Forms.Padding(4);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(100, 28);
            this.searchButton.TabIndex = 8;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // addNewStylistButton
            // 
            this.addNewStylistButton.AutoSize = true;
            this.addNewStylistButton.Location = new System.Drawing.Point(171, 312);
            this.addNewStylistButton.Margin = new System.Windows.Forms.Padding(4);
            this.addNewStylistButton.Name = "addNewStylistButton";
            this.addNewStylistButton.Size = new System.Drawing.Size(129, 28);
            this.addNewStylistButton.TabIndex = 7;
            this.addNewStylistButton.Text = "Add New Stylist";
            this.addNewStylistButton.UseVisualStyleBackColor = true;
            this.addNewStylistButton.Click += new System.EventHandler(this.addNewStylistButton_Click);
            // 
            // editStylistButton
            // 
            this.editStylistButton.Location = new System.Drawing.Point(16, 312);
            this.editStylistButton.Margin = new System.Windows.Forms.Padding(4);
            this.editStylistButton.Name = "editStylistButton";
            this.editStylistButton.Size = new System.Drawing.Size(147, 28);
            this.editStylistButton.TabIndex = 6;
            this.editStylistButton.Text = "Edit Selected Stylist";
            this.editStylistButton.UseVisualStyleBackColor = true;
            this.editStylistButton.Click += new System.EventHandler(this.editStylistButton_Click);
            // 
            // StylistListBox
            // 
            this.StylistListBox.FormattingEnabled = true;
            this.StylistListBox.ItemHeight = 16;
            this.StylistListBox.Location = new System.Drawing.Point(16, 46);
            this.StylistListBox.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.StylistListBox.Name = "StylistListBox";
            this.StylistListBox.Size = new System.Drawing.Size(608, 260);
            this.StylistListBox.TabIndex = 5;
            // 
            // bookChairButton
            // 
            this.bookChairButton.Location = new System.Drawing.Point(508, 312);
            this.bookChairButton.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.bookChairButton.Name = "bookChairButton";
            this.bookChairButton.Size = new System.Drawing.Size(119, 28);
            this.bookChairButton.TabIndex = 10;
            this.bookChairButton.Text = "Book Chair";
            this.bookChairButton.UseVisualStyleBackColor = true;
            this.bookChairButton.Click += new System.EventHandler(this.bookChairButton_Click);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(308, 313);
            this.dateTimePicker.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(189, 22);
            this.dateTimePicker.TabIndex = 11;
            // 
            // StylistSelectionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(627, 345);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.bookChairButton);
            this.Controls.Add(this.searchTextBox);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.addNewStylistButton);
            this.Controls.Add(this.editStylistButton);
            this.Controls.Add(this.StylistListBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "StylistSelectionForm";
            this.Text = "StylistSelectionForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Button addNewStylistButton;
        private System.Windows.Forms.Button editStylistButton;
        private System.Windows.Forms.ListBox StylistListBox;
        private System.Windows.Forms.Button bookChairButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
    }
}