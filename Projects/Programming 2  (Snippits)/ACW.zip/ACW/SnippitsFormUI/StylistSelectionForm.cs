﻿using System;
using System.Linq;
using System.Windows.Forms;
using SnippitsBusinessLogic;
using System.Collections.Generic;

namespace SnippitsFormUI
{
    public partial class StylistSelectionForm : Form
    {
        public StylistSelectionForm()
        {
            InitializeComponent();
            DrawStylistListBox();
        }
        private void addNewStylistButton_Click(object sender, EventArgs e)
        {
            StylistForm form = new StylistForm();
            form.ShowDialog();
            if (form.DialogResult == DialogResult.OK)
            {
                DrawStylistListBox();
            }
        }
        /// <summary>
        /// If editing a selected stylist, it is passed into the StylistForm as a parameter in a construcor
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void editStylistButton_Click(object sender, EventArgs e)
        {
            if (StylistListBox.SelectedItem == null)
            {
                MessageBox.Show("No stylist selected!");
            }
            else
            {
                Stylist stylist = (Stylist)StylistListBox.SelectedItem;
                StylistForm form = new StylistForm(stylist);
                form.ShowDialog();
                if (form.DialogResult == DialogResult.OK)
                {
                    DrawStylistListBox();
                }
            }
        }
        /// <summary>
        /// Method to refresh the List Box - if new stylists are added, this will cause them to be displayed.
        /// </summary>
        private void DrawStylistListBox()
        {
            StylistListBox.Items.Clear();
            foreach (Stylist S in MainForm.sList)
            {
                StylistListBox.Items.Add(S);
            }
        }
        /// <summary>
        /// Search feature for Stylists.
        /// If any Stylist contains the text being searched for, this stylist will be displayed in the listBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void searchButton_Click(object sender, EventArgs e)
        {
            StylistListBox.Items.Clear();
            foreach (Stylist S in MainForm.sList)
            {
                if (($"{S.Forename.ToUpper()} {S.Surname.ToUpper()}").Contains(searchTextBox.Text.ToUpper()))
                {
                    StylistListBox.Items.Add(S);
                }
            }
        }
        /// <summary>
        /// Booking a stylist into a chair on a specified date
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bookChairButton_Click(object sender, EventArgs e)
        {
            if (StylistListBox.SelectedItem == null)
            {
                MessageBox.Show("No stylist selected.");
            }
            else
            {
                Stylist stylist = (Stylist)StylistListBox.SelectedItem;
                DateTime date = (dateTimePicker.Value).Date; 
                int ChairBookingFee;
                // Identifying the day of the week of the selected date to determine the cost of booking a chair on this day
                if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
                {
                    ChairBookingFee = -75;
                }
                else
                {
                    ChairBookingFee = -50;
                }
                // List of all the initial available appointment times
                List<DateTime> TimeSlots = new List<DateTime> { (date.AddHours(9)), (date.AddHours(9).AddMinutes(30)), (date.AddHours(10)), (date.AddHours(10).AddMinutes(30)),
                (date.AddHours(11)), (date.AddHours(11).AddMinutes(30)), (date.AddHours(12)), (date.AddHours(12).AddMinutes(30)), (date.AddHours(13)), (date.AddHours(13).AddMinutes(30)),
                (date.AddHours(14)), (date.AddHours(14).AddMinutes(30)), (date.AddHours(15)), (date.AddHours(15).AddMinutes(30)), (date.AddHours(16)), (date.AddHours(16).AddMinutes(30))
                };

                // Checking if the dictionary contains the date selected already, 
                // if so, the Stylist is added to the Stylist list for this specified key
                if (MainForm.chairs.ContainsKey(date))
                {
                    for (int x = 0; x < MainForm.chairs[date].Length; x++)
                    {
                        if (MainForm.chairs[date][x] == stylist)
                        {
                            MessageBox.Show("This stylist has already booked a chair for this day.");
                            break;
                        }
                        else if (MainForm.chairs[date][x] != null)
                        {
                            continue;
                        }
                        else if (MainForm.chairs[date][x] == null)
                        {
                            MainForm.chairs[date][x] = stylist;
                            stylist.UpdateStylistBalance(ChairBookingFee);
                            stylist.StylistTransactions.Add($"Chair Booking on {date.ToShortDateString()} £{ChairBookingFee}");
                            MessageBox.Show($"{stylist} Chair Booking {date.ToShortDateString()} £{ChairBookingFee}");

                            MainForm.Availability.Add(new Tuple<Stylist, DateTime>(stylist, date), TimeSlots);
                            break;
                        }
                        else
                        {
                            MessageBox.Show("No more chairs available for this day.");
                        }
                    }
                }
                // If the dictionary does not contain this date as a key,
                // it is added, and a Stylist array of size 4 is created for the value to this key.
                else
                {
                    MainForm.chairs.Add(date, new Stylist[4]);
                    MainForm.chairs[date][0] = stylist;
                    stylist.UpdateStylistBalance(ChairBookingFee);
                    stylist.StylistTransactions.Add($"Chair Booking on {date.ToShortDateString()} £{ChairBookingFee}");
                    MessageBox.Show($"{stylist} chair booking on {date.ToShortDateString()} £{ChairBookingFee}");
                    MainForm.Availability.Add(new Tuple<Stylist, DateTime>(stylist, date), TimeSlots);
                }
            }
        }
    }
}
