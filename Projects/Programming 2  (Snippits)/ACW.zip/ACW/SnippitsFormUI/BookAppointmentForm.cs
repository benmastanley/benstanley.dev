﻿using SnippitsBusinessLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnippitsFormUI
{
    public partial class BookAppointmentForm : Form
    {
        private Customer mCustomer = null;
        public BookAppointmentForm(Customer cust)
        {
            mCustomer = cust;
            InitializeComponent();
            UpdateStylistsAvailable();
            UpdateTimes();
        }
        private void UpdateStylistsAvailable()
        {
            DateTime date = dateTimePicker.Value.Date;
            stylistComboBox.Items.Clear();
            stylistComboBox.Text = null;
            if (MainForm.chairs.ContainsKey(date.Date))
            {
                foreach (Stylist s in MainForm.chairs[date])
                {
                    if (s != null)
                    {
                        stylistComboBox.Items.Add(s);
                    }
                }
            }
        }
        private void UpdateTimes()
        {
            availableAppointmentsListBox.Items.Clear();
            if (stylistComboBox.SelectedItem != null)
            {
                Stylist stylist = (Stylist)stylistComboBox.SelectedItem;
                DateTime date = dateTimePicker.Value.Date;
                if (MainForm.Availability.ContainsKey(new Tuple<Stylist, DateTime>(stylist, date)))
                {
                    foreach (DateTime time in MainForm.Availability[new Tuple<Stylist, DateTime>(stylist, date)])
                    {
                        availableAppointmentsListBox.Items.Add(time);
                    }
                }
            }
        }
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            UpdateStylistsAvailable();
            UpdateTimes();
        }

        private void stylistComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Stylist stylist = (Stylist)stylistComboBox.SelectedItem;
            DateTime date = dateTimePicker.Value.Date;
            UpdateTimes();
        }

        private void bookAppointmentButton_Click(object sender, EventArgs e)
        {
            string error = "";
            if (availableAppointmentsListBox.SelectedItem == null)
            {
                error += "Please select an available appointment time.\r\n";
            }
            if (appointmentLengthComboBox.SelectedItem == null)
            {
                error += "Please select a duration for the appointment.\r\n";
            }
            if (error != "")
            {
                MessageBox.Show(error);
            }
            else
            {
                DateTime date = dateTimePicker.Value.Date;
                DateTime time = (DateTime)availableAppointmentsListBox.SelectedItem;
                int timeIndex = availableAppointmentsListBox.SelectedIndex;
                Stylist stylist = (Stylist)stylistComboBox.SelectedItem;

                MessageBox.Show($"Congratulations {mCustomer}, \r\nYou've booked a new appointment at {time} with {stylist}.");
                mCustomer.CustomerAppointments.Add($"{time} with {stylist}");
                stylist.StylistTransactions.Add($"Appointment with {mCustomer} at {time} £{stylist.HourlyRate}");
                stylist.UpdateStylistBalance(stylist.HourlyRate);

                if (appointmentLengthComboBox.SelectedIndex == 0)
                {
                    MainForm.Availability[new Tuple<Stylist, DateTime>(stylist, date)].Remove(time);
                }
                if (appointmentLengthComboBox.SelectedIndex == 1)
                {
                    MainForm.Availability[new Tuple<Stylist, DateTime>(stylist, date)].Remove(time);
                    MainForm.Availability[new Tuple<Stylist, DateTime>(stylist, date)].Remove((time.AddMinutes(30)));
                }
                this.Close();
            }
        }
    }
}
