﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnippitsBusinessLogic
{
    public interface Isetters //Interface to be implemented - ensures the member variables within the classes have setters and are accessible.
    {
        bool SetForename(string pForename, out string pError);
        bool SetSurname(string pSurname, out string pError);
        bool SetEmailAddress(string pEmailAddress, out string pError);
        bool SetPhoneNumber(string pPhoneNumber, out string pError);
    }
    public class Person
    {
        // PRIVATE MEMBER VARIABLES
        private string m_Forename;
        private string m_Surname;
        private string m_EmailAddress;
        private string m_PhoneNumber;

        // PROPERTIES THAT ACT AS GETTERS FOR OUR PRIVATE MEMBER VARIABLES
        public string Forename { get { return m_Forename; } }
        public string Surname { get { return m_Surname; } }
        public string EmailAddress { get { return m_EmailAddress; } }
        public string PhoneNumber { get { return m_PhoneNumber; } }

        // SETTERS FOR OUR PRIVATE MEMBER VARIABLES

        /// <summary>
        /// Validation of the Forename
        /// </summary>
        /// <param name="pForename"></param>
        /// <param name="pError"></param>
        /// <returns>True if meets criteria, else False and adds error feedback</returns>
        public bool SetForename(string pForename, out string pError)
        {
            pError = "";
            pForename = pForename.Trim();
            if (pForename == "")
            {
                pError += "Forename cannot be empty.\r\n";
            }
            if (pError == "")
            {
                m_Forename = pForename;
                return true;
            }
            return false;
        }
        /// <summary>
        /// Validation of the Surname
        /// </summary>
        /// <param name="pSurname"></param>
        /// <param name="pError"></param>
        /// <returns>True if meets criteria, else False and adds error feedback</returns>
        public bool SetSurname(string pSurname, out string pError)
        {
            pError = "";
            pSurname = pSurname.Trim();
            if (pSurname == "")
            {
                pError += "Surname cannot be empty.\r\n";
            }
            if (pError == "")
            {
                m_Surname = pSurname;
                return true;
            }
            return false;
        }
        /// <summary>
        /// Validation of the Email Address
        /// </summary>
        /// <param name="pEmailAddress"></param>
        /// <param name="pError"></param>
        /// <returns>True if meets criteria, else False and adds error feedback</returns>
        public bool SetEmailAddress(string pEmailAddress, out string pError)
        {
            pError = "";
            pEmailAddress = pEmailAddress.Trim();

            if (!(pEmailAddress.Contains('@')))
            {
                pError += "Email address must contain one @ symbol.\r\n";
            }
            else if (pEmailAddress.IndexOf('@') != pEmailAddress.LastIndexOf('@'))
            {
                pError += "Email address can only contain one @ symbol.\r\n";
            }

            if (!(pEmailAddress.Contains('.')))
            {
                pError += "Email address must contain one period.\r\n";
            }
            else if (pEmailAddress.IndexOf('.') != pEmailAddress.LastIndexOf('.'))
            {
                pError += "Email address can only contain one period.\r\n";
            }

            else if (pEmailAddress.IndexOf('.') < pEmailAddress.IndexOf('@'))
            {
                pError += "Email address cannot have a period before the @ symbol.\r\n";
            }
            else
            {
                if (pEmailAddress.Split('@')[0] == "")
                {
                    pError += "Email address must have one or more characters before the @ symbol.\r\n";
                }
                if (pEmailAddress.Split('@', '.')[1] == "")
                {
                    pError += "Email adress must have one or more characters between the @ symbol and the period.\r\n";
                }
                if (pEmailAddress.Split('.')[1] == "")
                {
                    pError += "Email address must have one or more characters after the period.\r\n";
                }
            }
            if (pError == "")
            {
                m_EmailAddress = pEmailAddress;
                return true;
            }
            else
            {
                pError += "Email must be in format : 'example@example.com'\r\n";
            }
            return false;
        }
        /// <summary>
        /// Validation of the Phone Number
        /// </summary>
        /// <param name="pPhoneNumber"></param>
        /// <param name="pError"></param>
        /// <returns>True if meets criteria, else False and adds error feedback</returns>
        public bool SetPhoneNumber(string pPhoneNumber, out string pError)
        {
            pError = "";
            try
            {
                long lPhoneNumber = long.Parse(pPhoneNumber);
            }
            catch
            {
                pError += "Phone number must contain numbers only.\r\n";
            }

            if (pPhoneNumber.Length != 11)
            {
                pError += "Phone number must be 11 digits long.\r\n";
            }
            if (pError == "")
            {
                m_PhoneNumber = pPhoneNumber;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Constructor for the base Person class - to be inherited by Stylist and Customer classes.
        /// </summary>
        /// <param name="_forename"></param>
        /// <param name="_surname"></param>
        /// <param name="_emailAddress"></param>
        /// <param name="_phoneNumber"></param>
        public Person(string _forename, string _surname, string _emailAddress, string _phoneNumber)
        {
            string allErrors = "";
            string error;

            SetForename(_forename, out error);
            allErrors += error;

            SetSurname(_surname, out error);
            allErrors += error;

            SetEmailAddress(_emailAddress, out error);
            allErrors += error;

            SetPhoneNumber(_phoneNumber, out error);
            allErrors += error;

            if (allErrors != "")
            {
                throw new Exception(allErrors);
            }
        }
        /// <summary>
        /// Overriding the default ToString method for the Person Class - use in ListBox/ComboBox
        /// </summary>
        /// <returns>The Stylist/Customer first and second name.</returns>
        public override string ToString()
        {
            return $"{m_Forename} {m_Surname}";
        }
    }

    /// <summary>
    /// Stylist class created, child class of 'Person'.
    /// Isetters interface also inherited.
    /// </summary>
    public class Stylist : Person, Isetters
    {
        public List<string> StylistTransactions = new List<string>();
        private int m_HourlyRate;
        private int m_StylistBalance;
        public int HourlyRate { get { return m_HourlyRate; } }
        public int StylistBalance { get { return m_StylistBalance; } }

        public bool SetHourlyRate(int pHourlyRate, out string pError)
        {
            pError = "";
            string error = "The hourly rate must be a whole number, with units of pounds(£)";
            try
            {
                string sHR = HourlyRate.ToString();
            }
            catch
            {
                pError += error;
            }
            if (pError == "")
            {
                m_HourlyRate = pHourlyRate;
                return true;
            }
            return false;
        }
        public bool UpdateStylistBalance(int pAmount)
        {
            try
            {
                m_StylistBalance += pAmount;
                return true;
            }
            catch
            {
                throw new Exception("Unable to update stylist balance");
            }
        }
        /// <summary>
        /// Calling the base Person constructor for all variable except for hourlyRate
        /// </summary>
        /// <param name="_forename"></param>
        /// <param name="_surname"></param>
        /// <param name="_emailAddress"></param>
        /// <param name="_phoneNumber"></param>
        /// <param name="_hourlyRate"></param>
        public Stylist(string _forename, string _surname, string _emailAddress, string _phoneNumber, int _hourlyRate) : base(_forename, _surname, _emailAddress, _phoneNumber)
        {
            m_StylistBalance = 0;
            string allErrors = "";
            string error;
            SetHourlyRate(_hourlyRate, out error);
            allErrors += error;

            if (allErrors != "")
            {
                throw new Exception(allErrors);
            }
        }
    }

    /// <summary>
    /// Customer Class created, 'Is A' Person.
    /// Inherits Person class and Isetters interface
    /// </summary>
    public class Customer : Person, Isetters
    {
        public List<string> CustomerAppointments = new List<string>();
        public Customer(string _forename, string _surname, string _emailAddress, string _phoneNumber) : base(_forename, _surname, _emailAddress, _phoneNumber)
        {
        }
    }
}