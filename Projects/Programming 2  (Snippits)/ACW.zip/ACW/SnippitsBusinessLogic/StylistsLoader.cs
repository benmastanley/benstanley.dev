﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SnippitsBusinessLogic
{
    public static class StylistsLoader
    {
        public static List<Stylist> LoadFromCSV(string pFilename, out string pError)
        {
            pError = "";
            List<Stylist> stylists = new List<Stylist>();
            StreamReader reader = null;
            try
            {
                reader = new StreamReader(pFilename);
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(',');
                    if (values.Length == 5)
                    {
                        string forename = values[0].Trim();
                        string surname = values[1].Trim();
                        string email = values[2].Trim();
                        string phoneNumber = values[3].Trim();
                        int hourlyRate = int.Parse(values[4]);
                        try
                        {
                            Stylist sty = new Stylist(forename, surname, email, phoneNumber, hourlyRate);
                            stylists.Add(sty);
                        }
                        catch (Exception ex)
                        {
                            pError = ex.Message;
                            return null;
                        }
                    }
                    else
                    {
                        pError = "Line in file in incorrect format:" + line;
                        return null;
                    }
                }
            }
            catch
            {
                pError = "Could not open file " + pFilename;
                return null;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }

            if (pError == "")
            {
                return stylists;
            }
            return null;
        }

        public static bool SaveToCSV(string pFilename, List<Stylist> pStylists, out string pError)
        {
            pError = "";
            if (!File.Exists(pFilename))
            {
                pError = "could not find file " + pFilename;
                return false;
            }
            StreamWriter writer = new StreamWriter(pFilename, false);
            foreach (Stylist S in pStylists)
            {
                writer.WriteLine(S.Forename + ", " + S.Surname + ", " + S.EmailAddress + ", " +
                    S.PhoneNumber + ", " + S.HourlyRate);
            }
            writer.Close();
            return true;
        }
    }
}
