﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SnippitsBusinessLogic
{
    public static class CustomersLoader
    {
        public static List<Customer> LoadFromCSV(string pFilename, out string pError)
        {
            pError = "";
            List<Customer> customers = new List<Customer>();
            StreamReader reader = null;
            try
            {
                reader = new StreamReader(pFilename);
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(',');
                    if (values.Length == 4)
                    {
                        string forename = values[0].Trim();
                        string surname = values[1].Trim();
                        string email = values[2].Trim();
                        string phoneNumber = values[3].Trim();
                        try
                        {
                            customers.Add(new Customer(forename, surname, email, phoneNumber));
                        }
                        catch (Exception ex)
                        {
                            pError = ex.Message;
                            return null;
                        }
                    }
                    else
                    {
                        pError = "Line in file in incorrect format:" + line;
                        return null;
                    }
                }
            }
            catch
            {
                pError = "Could not open file " + pFilename;
                return null;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }

            if (pError == "")
            {
                return customers;
            }
            return null;
        }
        public static bool SaveToCSV(string pFilename, List<Customer> pCustomers, out string pError)
        {
            pError = "";
            if (!File.Exists(pFilename))
            {
                pError = "could not find file " + pFilename;
                return false;
            }
            StreamWriter writer = new StreamWriter(pFilename, false);
            foreach (Customer C in pCustomers)
            {
                writer.WriteLine(C.Forename + ", " + C.Surname + ", " + C.EmailAddress + ", " +
                    C.PhoneNumber);
            }
            writer.Close();
            return true;
        }
    }
}
